import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:5000/api', // As per requirements
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add token if available (simulation)
axiosInstance.interceptors.request.use(
  (config) => {
    // In a real app with useAuthStore, we might inject the token header here
    // or rely on cookies (withCredentials: true).
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default axiosInstance;