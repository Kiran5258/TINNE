import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, Sale } from '../types';

interface ProductState {
  products: Product[];
  sales: Sale[];
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  getProduct: (id: string) => Product | undefined;
}

// Initial Mock Data
const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Traditional Millets',
    category: 'Millets',
    price: 180,
    image: 'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95',
    description: 'Premium quality traditional millets, rich in fiber and nutrients. Sourced from rain-fed farms.',
    sizes: ['1kg', '5kg'],
    inStock: true
  },
  {
    id: '2',
    title: 'Biriyani Rice Premium',
    category: 'Rice',
    price: 650,
    image: 'https://aistudiocdn.com/d/ef70b686-e91b-4f91-817e-7bf33f019054',
    description: 'Aromatic long-grain rice perfect for festive biriyanis. Aged to perfection.',
    sizes: ['5kg', '25kg'],
    inStock: true
  },
  {
    id: '3',
    title: 'White Rice',
    category: 'Rice',
    price: 450,
    image: 'https://aistudiocdn.com/d/312ac650-2c7b-402a-8c88-29ec3849567e',
    description: 'Daily use premium white rice processed with care to retain nutritional value.',
    sizes: ['5kg', '10kg'],
    inStock: true
  },
  {
    id: '4',
    title: 'Tinne Spices Pack',
    category: 'Spices',
    price: 320,
    image: 'https://aistudiocdn.com/d/3e4a2e5a-73d8-4fc5-9988-812699e34e55',
    description: 'Authentic spice blend from traditional recipes. Stone-ground.',
    sizes: ['100g', '250g'],
    inStock: true
  },
  {
    id: '5',
    title: 'Cashews Whole',
    category: 'Nuts',
    price: 850,
    image: 'https://images.unsplash.com/photo-1596208643924-f7c8702c2869?auto=format&fit=crop&q=80&w=400',
    description: 'Premium W320 grade whole cashews. Crunchy and sweet.',
    sizes: ['250g', '500g'],
    inStock: true
  },
  {
    id: '6',
    title: 'Cold Pressed Sesame Oil',
    category: 'Spices',
    price: 420,
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&q=80&w=400',
    description: 'Traditional wood-pressed sesame oil. Pure and unrefined.',
    sizes: ['500ml', '1L'],
    inStock: false
  }
];

const INITIAL_SALES: Sale[] = [
  { id: 'ORD-001', date: '2023-10-25', productTitle: 'Biriyani Rice Premium', amount: 1300, status: 'Completed', customer: 'Rahul M.' },
  { id: 'ORD-002', date: '2023-10-24', productTitle: 'Traditional Millets', amount: 360, status: 'Shipped', customer: 'Anita S.' },
  { id: 'ORD-003', date: '2023-10-24', productTitle: 'Tinne Spices Pack', amount: 320, status: 'Pending', customer: 'John D.' },
  { id: 'ORD-004', date: '2023-10-23', productTitle: 'White Rice', amount: 450, status: 'Completed', customer: 'Priya K.' },
];

export const useProductStore = create<ProductState>()(
  persist(
    (set, get) => ({
      products: INITIAL_PRODUCTS,
      sales: INITIAL_SALES,
      addProduct: (product) => set((state) => ({ products: [...state.products, product] })),
      updateProduct: (id, updates) => set((state) => ({
        products: state.products.map(p => p.id === id ? { ...p, ...updates } : p)
      })),
      deleteProduct: (id) => set((state) => ({
        products: state.products.filter(p => p.id !== id)
      })),
      getProduct: (id) => get().products.find(p => p.id === id),
    }),
    {
      name: 'tinne-product-storage',
    }
  )
);