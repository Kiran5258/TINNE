import { create } from 'zustand';
import { BlogPost } from '../types';

interface BlogState {
  posts: BlogPost[];
  getPostBySlug: (slug: string) => BlogPost | undefined;
  getPostsByCategory: (category: string) => BlogPost[];
  getFeaturedPosts: () => BlogPost[];
}

const MOCK_POSTS: BlogPost[] = [
  // 1. Field Notes from Indian Farms
  {
    id: '1',
    slug: 'red-millet-revival',
    title: 'The Red Millet Comeback: A Village Tale',
    excerpt: 'How one Tamil Nadu village revived a nearly lost cultivar of nutritious red millet, transforming local incomes and health.',
    category: 'Field Notes from Indian Farms',
    image: 'https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&q=80&w=1200',
    author: { name: 'Karthik R.', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'October 12, 2023',
    readingTime: '6 min read',
    tags: ['Millets', 'Farming', 'Heritage', 'Sustainability'],
    content: [
      { type: 'paragraph', text: 'In the heart of Thanjavur, a small collective of farmers decided to stop growing hybrid crops and return to their roots. This is the story of the Red Millet revival.' },
      { type: 'image', src: 'https://images.unsplash.com/photo-1596560548464-f010549b84d7?auto=format&fit=crop&q=80&w=1200', caption: 'Traditional millet fields at dawn.' },
      { type: 'heading', level: 2, text: 'The Challenge of Heritage' },
      { type: 'paragraph', text: 'Heritage crops grow taller and take longer to mature. But the nutritional payoff is immense. This millet is packed with antioxidants, iron, and zinc, far surpassing modern hybrids.' },
      { type: 'quote', text: 'We don’t just grow food; we grow health for the next generation.' },
      { type: 'paragraph', text: 'Rain-fed farming relies solely on rainfall for water. This stress on the plant forces it to develop deeper root systems and concentrate nutrients in the grain.' }
    ]
  },
  {
    id: '2',
    slug: 'women-led-cooperatives',
    title: 'Women Leading the Harvest',
    excerpt: 'The rise of women-led millet cooperatives in rural India is not just changing agriculture, it is changing society.',
    category: 'Field Notes from Indian Farms',
    image: 'https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&q=80&w=800',
    author: { name: 'Anitha S.', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'August 10, 2023',
    readingTime: '5 min read',
    tags: ['Community', 'Women', 'Impact'],
    content: [
      { type: 'paragraph', text: 'Empowering women through agriculture has a multiplier effect on the community. These cooperatives are not just growing food; they are growing independence.' },
      { type: 'image', src: 'https://images.unsplash.com/photo-1595266850020-008395f13d80?auto=format&fit=crop&q=80&w=1200', caption: 'Sorting the harvest by hand.' }
    ]
  },

  // 2. Rituals & Recipes
  {
    id: '3',
    slug: 'millet-risotto',
    title: 'Creamy Millet Risotto with Roasted Vegetables',
    excerpt: 'A modern Italian twist on the humble barnyard millet that brings luxury to your dinner table.',
    category: 'Rituals & Recipes',
    image: 'https://images.unsplash.com/photo-1646654497793-66f85d2634e3?auto=format&fit=crop&q=80&w=1200',
    author: { name: 'Chef Meera', avatar: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'October 05, 2023',
    readingTime: '15 min prep',
    tags: ['Recipe', 'Dinner', 'Vegetarian', 'Fusion'],
    content: [
      { type: 'paragraph', text: 'Who says risotto needs Arborio rice? Barnyard millet offers a similar creamy texture with a nuttier profile and lower glycemic index.' },
      { type: 'heading', level: 2, text: 'Ingredients' },
      { type: 'list', items: ['1 cup Barnyard Millet', '2 cups Vegetable Broth', '1 cup Mushrooms', '1/2 cup Parmesan Cheese', '2 tbsp Olive Oil', '1 clove Garlic'] },
      { type: 'heading', level: 2, text: 'Instructions' },
      { type: 'paragraph', text: '1. Toast the millet in a pan with some olive oil until fragrant.\n2. Slowly add broth ladle by ladle, stirring constantly, just like traditional risotto.\n3. Sauté mushrooms separately and fold them in at the end with parmesan.' },
      { type: 'image', src: 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?auto=format&fit=crop&q=80&w=1200', caption: 'The final plating.' }
    ]
  },
  {
    id: '4',
    slug: 'tempering-art',
    title: 'The Art of Authentic Tempering (Tadka)',
    excerpt: 'Mastering the tadka: How to release the full potential of spices in everyday cooking.',
    category: 'Rituals & Recipes',
    image: 'https://images.unsplash.com/photo-1604543788288-72656551b876?auto=format&fit=crop&q=80&w=800',
    author: { name: 'Chef Meera', avatar: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'August 15, 2023',
    readingTime: '5 min read',
    tags: ['Cooking Tips', 'Spices', 'Technique'],
    content: [
      { type: 'paragraph', text: 'Tempering, or Tadka, is not just about heating oil. It is about sequencing. Mustard seeds first, then lentils, then curry leaves. Each spice releases its oil at a different temperature.' }
    ]
  },

  // 3. People Who Shape Our Brand
  {
    id: '5',
    slug: 'spice-artisan-lakshmi',
    title: 'Lakshmi: The Spice Artisan',
    excerpt: 'Meet the master blender preserving recipes passed down for 4 generations in rural Kerala.',
    category: 'People Who Shape Our Brand',
    image: 'https://images.unsplash.com/photo-1556910103-1c02745a30bf?auto=format&fit=crop&q=80&w=800',
    author: { name: 'Tinné Editors', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'June 05, 2023',
    readingTime: '8 min read',
    tags: ['People', 'Heritage', 'Interview'],
    content: [
      { type: 'paragraph', text: 'Lakshmi wakes up at 4 AM every day. Her day begins not with coffee, but with the sound of the stone mortar. She is one of the few remaining artisans who hand-pounds spices to ensure the volatile oils are not lost to heat.' },
      { type: 'image', src: 'https://images.unsplash.com/photo-1596208643924-f7c8702c2869?auto=format&fit=crop&q=80&w=1200', caption: 'Lakshmi checking the quality of dried chilies.' },
      { type: 'quote', text: 'Machines chop the spice. Hands crush it. The flavor is in the crush.' },
      { type: 'heading', level: 2, text: 'A Dying Art' },
      { type: 'paragraph', text: 'In a world of industrial pulverizers, Lakshmi’s rhythm is a reminder that some things cannot be rushed. Her blends are used in our signature Sambar Powder.' }
    ]
  },

  // 4. Backed by Science
  {
    id: '6',
    slug: 'science-cold-pressed',
    title: 'Why Cold-Pressed Podi Retains Volatiles',
    excerpt: 'The chemistry of flavor: How low-temperature processing preserves the medicinal value of spices.',
    category: 'Backed by Science',
    image: 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?auto=format&fit=crop&q=80&w=1200',
    author: { name: 'Dr. Shiva', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'July 10, 2023',
    readingTime: '5 min read',
    tags: ['Science', 'Nutrition', 'Processing'],
    content: [
      { type: 'paragraph', text: 'Most commercial spice powders are ground at high speeds, generating temperatures up to 90°C. This destroys volatile essential oils like piperine and curcumin.' },
      { type: 'heading', level: 2, text: 'The Tinné Method' },
      { type: 'paragraph', text: 'Our "Cool-Grind" technology ensures the chamber temperature never exceeds 30°C. This preserves the full pharmacological potency of the spice.' },
      { type: 'list', items: ['Higher antioxidant retention', 'Richer aroma profile', 'Longer shelf life without preservatives'] }
    ]
  },
  {
    id: '7',
    slug: 'slow-release-carbs',
    title: 'The Science of Slow-Release Carbs',
    excerpt: 'Why millets provide sustained energy without the sugar crash compared to white rice.',
    category: 'Backed by Science',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=800',
    author: { name: 'Nutrition Team', avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200' },
    publishedAt: 'June 20, 2023',
    readingTime: '4 min read',
    tags: ['Health', 'Diabetes', 'Millets'],
    content: [
      { type: 'paragraph', text: 'Millets have a complex starch structure that takes longer for the body to break down. This results in a slow, steady release of glucose into the bloodstream, preventing insulin spikes.' }
    ]
  }
];

export const useBlogStore = create<BlogState>((set, get) => ({
  posts: MOCK_POSTS,
  getPostBySlug: (slug) => get().posts.find(p => p.slug === slug),
  getPostsByCategory: (category) => get().posts.filter(p => p.category === category),
  getFeaturedPosts: () => get().posts.slice(0, 3),
}));