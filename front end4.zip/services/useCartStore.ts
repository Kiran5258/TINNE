import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, Product } from '../types';

interface CartState {
  items: CartItem[];
  addItem: (product: Product, size?: string) => void;
  removeItem: (id: string, size?: string) => void;
  updateQuantity: (id: string, size: string | undefined, quantity: number) => void;
  clearCart: () => void;
  getCartCount: () => number;
  getCartTotal: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (product, size) => set((state) => {
        const itemSize = size || product.sizes[0];
        const existingItemIndex = state.items.findIndex(
          item => item.id === product.id && item.selectedSize === itemSize
        );

        if (existingItemIndex > -1) {
          const newItems = [...state.items];
          newItems[existingItemIndex].quantity += 1;
          return { items: newItems };
        }

        return { 
          items: [...state.items, { ...product, quantity: 1, selectedSize: itemSize }] 
        };
      }),
      removeItem: (id, size) => set((state) => ({
        items: state.items.filter(item => !(item.id === id && item.selectedSize === size))
      })),
      updateQuantity: (id, size, quantity) => set((state) => ({
        items: state.items.map(item => {
          if (item.id === id && item.selectedSize === size) {
            return { ...item, quantity: Math.max(1, quantity) };
          }
          return item;
        })
      })),
      clearCart: () => set({ items: [] }),
      getCartCount: () => {
        return get().items.reduce((total, item) => total + item.quantity, 0);
      },
      getCartTotal: () => {
        return get().items.reduce((total, item) => total + (item.price * item.quantity), 0);
      }
    }),
    {
      name: 'tinne-cart-storage',
    }
  )
);