import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../services/useAuthStore';
import { IconUser, IconMapPin, IconBox, IconLogout, IconPlus, IconBarChart } from '../components/Icons';

export const AccountLayout: React.FC = () => {
  const { logout, user } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const menuItems = [
    { label: 'Profile', path: '/account/profile', icon: IconUser },
    { label: 'Orders', path: '/account/orders', icon: IconBox },
    { label: 'Addresses', path: '/account/addresses', icon: IconMapPin },
  ];

  // If admin, add dashboard and product link
  if (user?.role === 'admin') {
    menuItems.unshift({ label: 'Admin Dashboard', path: '/account/admin', icon: IconBarChart });
    menuItems.push({ label: 'Add Product', path: '/account/add-product', icon: IconPlus });
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 min-h-[60vh]">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <aside className="w-full md:w-64 flex-shrink-0">
          <div className="bg-neutral-50 rounded-2xl p-6 sticky top-24">
            <div className="flex items-center space-x-3 mb-8 pb-8 border-b border-neutral-200">
              <div className="w-12 h-12 rounded-full bg-brand-dark text-white flex items-center justify-center font-bold text-lg">
                {user?.name.charAt(0)}
              </div>
              <div>
                <p className="font-bold text-neutral-900">{user?.name}</p>
                <p className="text-xs text-neutral-500">{user?.email}</p>
              </div>
            </div>
            
            <nav className="space-y-2">
              {menuItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => 
                    `flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors ${
                      isActive 
                        ? 'bg-white shadow-sm text-brand-dark font-medium' 
                        : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
                    }`
                  }
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </NavLink>
              ))}
              
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-colors mt-8"
              >
                <IconLogout className="w-5 h-5" />
                <span>Log Out</span>
              </button>
            </nav>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 bg-white rounded-2xl min-h-[500px]">
          <Outlet />
        </main>
      </div>
    </div>
  );
};