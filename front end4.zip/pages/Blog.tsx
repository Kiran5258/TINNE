import React from 'react';
import { Link } from 'react-router-dom';
import { 
  IconArrowRight, 
  IconBookOpen, 
  IconFeather, 
  IconLeaf, 
  IconShieldCheck, 
  IconTruck, 
  IconUtensils, 
  IconScience, 
  IconGlobe, 
  IconUsers 
} from '../components/Icons';
import { Button } from '../components/Button';
import { Reveal } from '../components/Reveal';
import { useBlogStore } from '../services/useBlogStore';
import { BlogCard } from '../components/BlogCard';

export const Blog: React.FC = () => {
  const { posts, getPostsByCategory } = useBlogStore();

  const featured = posts.find(p => p.slug === 'red-millet-revival');
  
  // Specific Categories
  const fieldNotes = getPostsByCategory('Field Notes from Indian Farms');
  const recipes = getPostsByCategory('Rituals & Recipes');
  const science = getPostsByCategory('Backed by Science');
  const people = getPostsByCategory('People Who Shape Our Brand');
  
  // We'll use the first "People" story as the artisan highlight
  const artisan = people.length > 0 ? people[0] : null;

  return (
    <div className="pt-20 min-h-screen bg-neutral-50 font-sans selection:bg-brand-accent selection:text-brand-dark">
      
      {/* 1. Hero Section */}
      <header className="bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-dark via-brand-accent to-brand-dark"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 pointer-events-none"></div>
        
        <div className="max-w-5xl mx-auto px-6 py-28 text-center relative z-10">
          <Reveal>
            <div className="inline-flex items-center justify-center p-3 bg-neutral-100 rounded-full mb-8">
              <IconBookOpen className="w-6 h-6 text-brand-dark" />
            </div>
            <h1 className="text-5xl md:text-8xl font-display font-bold text-neutral-900 mb-6 tracking-tight">
              Tinné Journal
            </h1>
            <div className="h-1 w-24 bg-brand-accent mx-auto mb-8"></div>
            <p className="text-xl md:text-3xl text-neutral-600 font-light tracking-wide mb-6 font-display">
              Insights. Origins. Innovations.
            </p>
            <p className="text-sm md:text-base text-neutral-500 uppercase tracking-widest font-medium max-w-2xl mx-auto leading-relaxed">
              A curated space where heritage food culture meets modern research, supply-chain intelligence, and sustainability.
            </p>
          </Reveal>
        </div>
      </header>

      {/* 2. Featured Editorial */}
      {featured && (
        <section className="py-20 px-6 max-w-7xl mx-auto">
          <Reveal>
            <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-neutral-100 grid lg:grid-cols-2">
              <Link to={`/blog/${featured.slug}`} target="_blank" rel="noopener noreferrer" className="relative h-96 lg:h-auto overflow-hidden group block">
                <img 
                  src={featured.image} 
                  alt={featured.title} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                <div className="absolute bottom-8 left-8 text-white">
                  <span className="bg-brand-accent text-brand-dark text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest mb-3 inline-block">
                    Featured Editorial
                  </span>
                </div>
              </Link>
              <div className="p-10 lg:p-16 flex flex-col justify-center">
                <h2 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-4 leading-tight">
                  <Link to={`/blog/${featured.slug}`} target="_blank" rel="noopener noreferrer" className="hover:text-brand-accent transition-colors">
                    {featured.title}
                  </Link>
                </h2>
                <div className="space-y-6 text-neutral-600 leading-relaxed mb-8">
                  <p>{featured.excerpt}</p>
                </div>
                <Link to={`/blog/${featured.slug}`} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="border-brand-dark text-brand-dark hover:bg-brand-dark hover:text-white">
                    Read Full Story <IconArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </Reveal>
        </section>
      )}

      {/* 3. From the Source (Field Notes) */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-12">
          <Reveal>
            <div className="flex items-center space-x-3 mb-2">
              <IconLeaf className="w-5 h-5 text-brand-accent" />
              <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">From the Source</span>
            </div>
            <h2 className="text-4xl font-display font-bold text-neutral-900">Field Notes from Indian Farms</h2>
          </Reveal>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {fieldNotes.map((item, i) => (
            <Reveal key={item.id} delay={i * 100}>
              <BlogCard post={item} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* 4. Behind the Craft (Dark Section) */}
      <section className="py-24 bg-neutral-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <Reveal>
             <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
                <div>
                  <div className="flex items-center space-x-3 mb-3">
                    <IconShieldCheck className="w-5 h-5 text-brand-accent" />
                    <span className="text-xs font-bold uppercase tracking-widest text-neutral-400">Behind the Craft</span>
                  </div>
                  <h2 className="text-4xl md:text-5xl font-display font-bold">Processing Innovations</h2>
                  <p className="text-neutral-400 mt-4 max-w-xl text-lg">
                    Deep-dive documentation of the techniques that make Tinné premium. How technology enhances heritage.
                  </p>
                </div>
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-brand-dark">
                  View All Tech specs
                </Button>
             </div>
          </Reveal>

          <div className="grid md:grid-cols-2 gap-12">
            {[
              {
                title: "Stone-Ground vs Industrial",
                desc: "Why traditional slow milling retains vital nutrients that high-heat industrial blades destroy.",
                stat: "40% More Nutrient Retention"
              },
              {
                title: "Nitrogen Flushing",
                desc: "The science of using inert gas to prevent oxidation, keeping nuts and spices fresh without preservatives.",
                stat: "6mo Extended Freshness"
              },
              {
                title: "Cold-Pressed Extraction",
                desc: "Avoiding heat damage to preserve the volatile oils that give our spices their signature depth.",
                stat: "< 27°C Extraction Temp"
              },
              {
                title: "Micro-Batch Roasting",
                desc: "Roasting in small lots ensures every grain receives equal heat, preventing charring and maximizing flavor.",
                stat: "Zero Char Policy"
              }
            ].map((item, i) => (
              <Reveal key={i} delay={i * 100} className="bg-white/5 border border-white/10 p-8 rounded-2xl hover:bg-white/10 transition-colors cursor-pointer">
                <h3 className="text-2xl font-bold mb-3 text-brand-accent">{item.title}</h3>
                <p className="text-neutral-300 mb-6 leading-relaxed">{item.desc}</p>
                <div className="h-px w-full bg-white/10 mb-4"></div>
                <span className="font-mono text-sm text-brand-muted">{item.stat}</span>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Supply Chain & Recipes (Split) */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-12 gap-16">
          
          {/* Supply Chain - Left Col */}
          <div className="lg:col-span-5">
            <Reveal>
              <div className="flex items-center space-x-3 mb-4">
                <IconTruck className="w-5 h-5 text-brand-accent" />
                <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Supply Chain Diaries</span>
              </div>
              <h2 className="text-3xl font-display font-bold text-neutral-900 mb-6">Traceability & Transparency</h2>
              <p className="text-neutral-600 mb-8">
                Modern luxury foods are not just about taste — they are about trust. We share insights into how every batch is logged, monitored, and audited.
              </p>

              <div className="space-y-6">
                {[
                  "Digital traceability for every SKU",
                  "Batch testing inside our facilities",
                  "Temperature-controlled logistics",
                  "Zero-waste packaging pipelines"
                ].map((item, i) => (
                  <div key={i} className="flex items-center p-4 bg-white rounded-xl shadow-sm border border-neutral-100">
                    <IconGlobe className="w-5 h-5 text-neutral-400 mr-4" />
                    <span className="font-medium text-neutral-800">{item}</span>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          {/* Recipes - Right Col */}
          <div className="lg:col-span-7">
            <Reveal delay={200}>
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <IconUtensils className="w-5 h-5 text-brand-accent" />
                  <h2 className="text-3xl font-display font-bold text-neutral-900">Rituals & Recipes</h2>
                </div>
                <span className="text-sm font-bold text-brand-dark">View All</span>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                 {recipes.slice(0, 2).map((item) => (
                   <BlogCard key={item.id} post={item} compact />
                 ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* 6. Science & Stories */}
      <section className="py-24 bg-white border-t border-neutral-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16">
            
            {/* Science */}
            <Reveal>
              <div className="mb-8">
                 <div className="flex items-center space-x-3 mb-2">
                    <IconScience className="w-5 h-5 text-brand-accent" />
                    <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Nutritional Intelligence</span>
                 </div>
                 <h2 className="text-3xl font-display font-bold text-neutral-900">Backed by Science</h2>
              </div>
              <div className="space-y-4">
                {science.map((item, i) => (
                  <Link key={i} to={`/blog/${item.slug}`} target="_blank" rel="noopener noreferrer" className="block p-6 bg-neutral-50 rounded-xl hover:bg-neutral-100 transition-colors">
                    <h3 className="font-bold text-lg mb-2 text-brand-dark">{item.title}</h3>
                    <p className="text-sm text-neutral-600 line-clamp-2">{item.excerpt}</p>
                  </Link>
                ))}
              </div>
            </Reveal>

            {/* People */}
            {artisan && (
              <Reveal delay={200}>
                <div className="mb-8">
                   <div className="flex items-center space-x-3 mb-2">
                      <IconUsers className="w-5 h-5 text-brand-accent" />
                      <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Tinné Stories</span>
                   </div>
                   <h2 className="text-3xl font-display font-bold text-neutral-900">People Who Shape Our Brand</h2>
                </div>
                <Link to={`/blog/${artisan.slug}`} target="_blank" rel="noopener noreferrer" className="relative bg-neutral-900 rounded-3xl overflow-hidden text-white p-8 h-[400px] flex flex-col justify-end group block">
                   <img src={artisan.image} alt={artisan.title} className="absolute inset-0 w-full h-full object-cover opacity-60 transition-transform duration-700 group-hover:scale-105" />
                   <div className="relative z-10">
                     <div className="bg-brand-accent text-brand-dark text-xs font-bold px-3 py-1 rounded-full w-max mb-3">Profile</div>
                     <h3 className="text-2xl font-bold mb-2 group-hover:text-brand-accent transition-colors">{artisan.title}</h3>
                     <p className="text-neutral-200 text-sm mb-6 line-clamp-2">
                       {artisan.excerpt}
                     </p>
                     <span className="text-sm font-bold flex items-center hover:underline">
                       Read Her Story <IconArrowRight className="ml-2 w-4 h-4" />
                     </span>
                   </div>
                </Link>
              </Reveal>
            )}
          </div>
        </div>
      </section>

      {/* 7. Footer / Newsletter */}
      <section className="py-24 bg-brand-muted text-center px-6">
        <Reveal>
          <IconFeather className="w-12 h-12 text-neutral-300 mx-auto mb-6" />
          <h2 className="text-3xl md:text-5xl font-display font-bold text-neutral-900 mb-6">
            Join the <span className="text-brand-accent font-script font-normal">Tinné</span> Community
          </h2>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto mb-10">
            Get weekly insights on heritage foods, exclusive recipes, and early access to small-batch harvests.
          </p>
          <div className="max-w-md mx-auto flex">
            <input 
              type="email" 
              placeholder="Enter your email address" 
              className="flex-grow px-6 py-4 rounded-l-full border-none focus:ring-2 focus:ring-brand-accent outline-none shadow-sm"
            />
            <button className="bg-brand-dark text-white px-8 py-4 rounded-r-full font-bold hover:bg-neutral-800 transition-colors">
              Subscribe
            </button>
          </div>
        </Reveal>
      </section>

    </div>
  );
};