import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';
import { useProductStore } from '../services/useProductStore';
import { Reveal } from '../components/Reveal';
import { IconClose } from '../components/Icons';

interface ProductsProps {
  category?: string;
}

const CATEGORIES = [
  { id: 'all', label: 'All Products', path: '/products' },
  { id: 'millet', label: 'Millets', path: '/products/millet' },
  { id: 'nuts', label: 'Nuts', path: '/products/nuts' },
  { id: 'rice', label: 'Rice', path: '/products/rice' },
  { id: 'spices', label: 'Spices', path: '/products/spices' }
];

export const Products: React.FC<ProductsProps> = ({ category: propCategory }) => {
  const { category: paramCategory } = useParams<{ category: string }>();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search');
  
  const activeCategory = propCategory || paramCategory || 'all';
  const navigate = useNavigate();
  
  const { products: allProducts } = useProductStore();
  const [displayProducts, setDisplayProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Determine display title
  const getTitle = () => {
    if (searchQuery) return `Search Results for "${searchQuery}"`;
    switch(activeCategory) {
      case 'millet': return 'Ancient Millets';
      case 'nuts': return 'Premium Nuts';
      case 'rice': return 'Organic Rice';
      case 'spices': return 'Aromatic Spices';
      default: return 'All Products';
    }
  };

  useEffect(() => {
    setLoading(true);
    // Simulate slight delay for transition feel
    const timer = setTimeout(() => {
      let filtered = [...allProducts];
      
      if (searchQuery) {
        const query = searchQuery.toLowerCase().trim();
        filtered = filtered.filter(p => 
          p.title.toLowerCase().includes(query) || 
          p.description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
        );
      } else if (activeCategory !== 'all') {
        // Filter by category if not searching
        filtered = filtered.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());
      }

      setDisplayProducts(filtered);
      setLoading(false);
    }, 400);

    return () => clearTimeout(timer);
  }, [activeCategory, allProducts, searchQuery]);

  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Category Slider - Hide if searching to keep focus on results */}
        {!searchQuery && (
          <div className="mb-12 overflow-x-auto no-scrollbar py-2">
            <div className="flex space-x-3 min-w-max">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => navigate(cat.path)}
                  className={`px-6 py-3 rounded-full text-sm font-medium transition-all duration-300 border ${
                    (activeCategory === cat.id || (activeCategory === 'all' && cat.id === 'all'))
                      ? 'bg-brand-dark text-white border-brand-dark shadow-md' 
                      : 'bg-white text-neutral-600 border-neutral-200 hover:border-brand-accent hover:text-brand-dark'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <header className="mb-8 flex justify-between items-end border-b border-neutral-100 pb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-3 capitalize">
              {getTitle()}
            </h1>
            <p className="text-neutral-500 max-w-2xl">
              {searchQuery 
                ? `Found ${displayProducts.length} results matching your search.` 
                : 'Browse our collection of ethically sourced, premium quality bulk ingredients.'}
            </p>
          </div>
          {searchQuery && (
            <button 
              onClick={() => navigate('/products')}
              className="text-sm font-medium text-brand-accent hover:text-brand-dark flex items-center bg-neutral-50 px-3 py-2 rounded-full hover:bg-neutral-100 transition-colors"
            >
              Clear Search <IconClose className="w-4 h-4 ml-1" />
            </button>
          )}
        </header>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
             {[1, 2, 3, 4, 5, 6].map(n => (
               <div key={n} className="h-96 bg-neutral-100 rounded-2xl animate-pulse"></div>
             ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {displayProducts.length > 0 ? (
              displayProducts.map((product, idx) => (
                <Reveal key={product.id} delay={idx * 50}>
                  <ProductCard product={product} />
                </Reveal>
              ))
            ) : (
              <div className="col-span-full py-24 text-center text-neutral-400 bg-neutral-50 rounded-2xl border border-neutral-100">
                <p className="text-xl font-display font-bold text-neutral-600 mb-2">No products found</p>
                <p className="text-sm">Try adjusting your search terms or filters.</p>
                {searchQuery && (
                  <button 
                    onClick={() => navigate('/products')}
                    className="mt-6 text-brand-dark font-bold hover:text-brand-accent underline underline-offset-4"
                  >
                    View all products
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};