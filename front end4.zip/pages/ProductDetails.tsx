import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { IconStar, IconCheck, IconBag, IconMinus, IconPlus, IconMessageCircle, IconCornerDownRight, IconUser } from '../components/Icons';
import { useCartStore } from '../services/useCartStore';
import { useProductStore } from '../services/useProductStore';
import { Product } from '../types';

interface Review {
  id: number;
  user: string;
  rating: number;
  date: string;
  text: string;
  replies: {
    user: string;
    text: string;
    date: string;
    isAdmin?: boolean;
  }[];
}

const MOCK_REVIEWS: Review[] = [
  {
    id: 1,
    user: "Anjali S.",
    rating: 5,
    date: "Oct 15, 2023",
    text: "Absolutely fantastic quality. The aroma filled my entire house when I cooked it. Reminds me of the rice my grandmother used to use.",
    replies: [
      { user: "Tinné Team", text: "Thank you Anjali! That is exactly the memory we hope to evoke.", date: "Oct 16, 2023", isAdmin: true }
    ]
  },
  {
    id: 2,
    user: "Rahul K.",
    rating: 4,
    date: "Sep 28, 2023",
    text: "Great texture and taste. The packaging was also very secure. Just wish the 25kg bag was in stock more often.",
    replies: []
  }
];

export const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [isAdded, setIsAdded] = useState(false);

  // Review Form States
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [replyText, setReplyText] = useState<{ [key: number]: string }>({});
  const [activeReplyId, setActiveReplyId] = useState<number | null>(null);

  const { addItem } = useCartStore();
  const { getProduct } = useProductStore();

  useEffect(() => {
    // Simulate API Fetch to find product in store
    setLoading(true);
    setTimeout(() => {
      const p = getProduct(id || '');
      setProduct(p);
      if (p && p.sizes.length > 0) {
        setSelectedSize(p.sizes[0]);
      }
      setLoading(false);
    }, 300);
  }, [id, getProduct]);

  const handleAddToCart = () => {
    if (product) {
      // Add logic to handle quantity if store supports it differently, or call addItem multiple times
      // For this demo, assuming store handles unique item merging
      for(let i = 0; i < quantity; i++) {
        addItem(product, selectedSize);
      }
      setIsAdded(true);
      setTimeout(() => setIsAdded(false), 2000);
    }
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim()) return;

    const newReview: Review = {
      id: Date.now(),
      user: "You", // In real app, get from AuthStore
      rating: newReviewRating,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      text: newReviewText,
      replies: []
    };

    setReviews([newReview, ...reviews]);
    setNewReviewText('');
    setNewReviewRating(5);
  };

  const handleSubmitReply = (reviewId: number) => {
    if (!replyText[reviewId]?.trim()) return;

    const updatedReviews = reviews.map(review => {
      if (review.id === reviewId) {
        return {
          ...review,
          replies: [...review.replies, {
            user: "You",
            text: replyText[reviewId],
            date: "Just now",
            isAdmin: false
          }]
        };
      }
      return review;
    });

    setReviews(updatedReviews);
    setReplyText({ ...replyText, [reviewId]: '' });
    setActiveReplyId(null);
  };

  if (loading) {
    return (
      <div className="pt-32 pb-20 max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-neutral-100 aspect-square rounded-2xl animate-pulse"></div>
        <div className="space-y-4">
          <div className="h-8 bg-neutral-100 rounded w-3/4 animate-pulse"></div>
          <div className="h-4 bg-neutral-100 rounded w-1/2 animate-pulse"></div>
          <div className="h-32 bg-neutral-100 rounded w-full animate-pulse"></div>
        </div>
      </div>
    );
  }

  if (!product) return (
    <div className="pt-32 pb-20 text-center min-h-[50vh]">
      <h2 className="text-2xl font-bold text-neutral-900">Product not found</h2>
      <Link to="/products" className="text-brand-accent mt-4 inline-block hover:underline">Return to Shop</Link>
    </div>
  );

  return (
    <div className="pt-24 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Breadcrumb */}
        <div className="text-sm text-neutral-500 mb-8">
          <Link to="/" className="hover:text-brand-dark">Home</Link> / 
          <Link to="/products" className="hover:text-brand-dark ml-1">Products</Link> / 
          <span className="text-brand-dark font-medium ml-1">{product.title}</span>
        </div>

        {/* Product Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-24">
          
          {/* Image Gallery */}
          <div className="bg-neutral-50 rounded-3xl overflow-hidden border border-neutral-100 p-8 flex items-center justify-center">
            <img 
              src={product.image} 
              alt={product.title} 
              className="max-h-[500px] w-full object-contain drop-shadow-xl hover:scale-105 transition-transform duration-700"
            />
          </div>

          {/* Product Info */}
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl md:text-5xl font-display font-bold text-neutral-900 mb-4">{product.title}</h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <span className="text-3xl font-display font-bold text-brand-dark">₹{product.price.toFixed(2)}</span>
              {product.inStock ? (
                <span className="bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                  In Stock
                </span>
              ) : (
                <span className="bg-red-100 text-red-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                  Out of Stock
                </span>
              )}
              <div className="flex items-center text-yellow-400">
                <IconStar className="w-5 h-5" fill />
                <span className="text-neutral-500 text-sm ml-2 font-sans font-medium text-black">(4.8/5)</span>
              </div>
            </div>

            <p className="text-neutral-600 text-lg leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Size Selector */}
            {product.sizes.length > 0 && (
              <div className="mb-8">
                <label className="block text-sm font-bold text-neutral-900 mb-3">Select Size</label>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-6 py-3 rounded-xl border font-medium transition-all ${
                        selectedSize === size
                          ? 'border-brand-dark bg-brand-dark text-white shadow-md'
                          : 'border-neutral-200 text-neutral-600 hover:border-brand-accent'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity & Add to Cart */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <div className="flex items-center border border-neutral-200 rounded-xl px-4 py-3 bg-neutral-50 w-max">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-1 hover:text-brand-accent transition-colors"
                >
                  <IconMinus className="w-5 h-5" />
                </button>
                <span className="w-12 text-center font-bold text-lg">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-1 hover:text-brand-accent transition-colors"
                >
                  <IconPlus className="w-5 h-5" />
                </button>
              </div>

              <Button 
                size="lg" 
                className={`flex-grow transition-all ${isAdded ? "bg-green-600 hover:bg-green-700" : ""}`}
                onClick={handleAddToCart}
                disabled={!product.inStock}
              >
                {isAdded ? (
                  <>
                    <IconCheck className="w-5 h-5 mr-2" /> Added to Bag
                  </>
                ) : (
                  <>
                    <IconBag className="w-5 h-5 mr-2" /> {product.inStock ? 'Add to Bag' : 'Out of Stock'}
                  </>
                )}
              </Button>
            </div>

            {/* Quick Benefits */}
            <div className="border-t border-neutral-100 pt-8 grid grid-cols-2 gap-4 text-sm text-neutral-500">
              <div className="flex items-center"><IconCheck className="w-4 h-4 text-brand-accent mr-2" /> Ethically Sourced</div>
              <div className="flex items-center"><IconCheck className="w-4 h-4 text-brand-accent mr-2" /> Chemical Free</div>
              <div className="flex items-center"><IconCheck className="w-4 h-4 text-brand-accent mr-2" /> Premium Quality</div>
              <div className="flex items-center"><IconCheck className="w-4 h-4 text-brand-accent mr-2" /> Secure Packaging</div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="border-t border-neutral-100 pt-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-display font-bold text-neutral-900 mb-10 text-center">Customer Reviews</h2>

            {/* Write Review */}
            <div className="bg-neutral-50 rounded-2xl p-8 mb-12 border border-neutral-100">
              <h3 className="text-lg font-bold mb-4">Write a Review</h3>
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div className="flex items-center space-x-2 mb-2">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button 
                      key={star} 
                      type="button" 
                      onClick={() => setNewReviewRating(star)}
                      className={`${star <= newReviewRating ? 'text-yellow-400' : 'text-neutral-300'} transition-colors`}
                    >
                      <IconStar className="w-6 h-6" fill={star <= newReviewRating} />
                    </button>
                  ))}
                </div>
                <textarea 
                  value={newReviewText}
                  onChange={(e) => setNewReviewText(e.target.value)}
                  placeholder="Share your experience with this product..."
                  className="w-full p-4 rounded-xl border border-neutral-200 focus:ring-2 focus:ring-brand-accent/50 outline-none min-h-[100px]"
                />
                <div className="flex justify-end">
                  <Button type="submit" size="sm">Submit Review</Button>
                </div>
              </form>
            </div>

            {/* Review List */}
            <div className="space-y-8">
              {reviews.map(review => (
                <div key={review.id} className="border-b border-neutral-100 pb-8 last:border-0">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-brand-dark text-white rounded-full flex items-center justify-center font-bold">
                        {review.user.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-neutral-900">{review.user}</h4>
                        <span className="text-xs text-neutral-400">{review.date}</span>
                      </div>
                    </div>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <IconStar key={i} className="w-4 h-4" fill={i < review.rating} />
                      ))}
                    </div>
                  </div>
                  
                  <p className="text-neutral-600 mb-4 pl-14">
                    {review.text}
                  </p>

                  <div className="pl-14">
                    <button 
                      onClick={() => setActiveReplyId(activeReplyId === review.id ? null : review.id)}
                      className="flex items-center text-sm font-bold text-neutral-500 hover:text-brand-dark transition-colors mb-4"
                    >
                      <IconMessageCircle className="w-4 h-4 mr-1" /> Reply
                    </button>

                    {/* Replies */}
                    {review.replies.length > 0 && (
                      <div className="space-y-4 mb-4">
                        {review.replies.map((reply, idx) => (
                          <div key={idx} className="bg-neutral-50 p-4 rounded-xl flex gap-3">
                            <IconCornerDownRight className="w-5 h-5 text-neutral-300 flex-shrink-0" />
                            <div>
                               <div className="flex items-center gap-2 mb-1">
                                 <span className={`text-sm font-bold ${reply.isAdmin ? 'text-brand-dark' : 'text-neutral-900'}`}>
                                   {reply.user}
                                   {reply.isAdmin && <span className="ml-2 bg-brand-accent/20 text-brand-dark text-[10px] px-2 py-0.5 rounded-full uppercase">Official</span>}
                                 </span>
                                 <span className="text-xs text-neutral-400">{reply.date}</span>
                               </div>
                               <p className="text-sm text-neutral-600">{reply.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Reply Input */}
                    {activeReplyId === review.id && (
                      <div className="flex gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                        <input 
                          type="text" 
                          value={replyText[review.id] || ''}
                          onChange={(e) => setReplyText({ ...replyText, [review.id]: e.target.value })}
                          placeholder="Write a reply..."
                          className="flex-grow px-4 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:border-brand-accent"
                        />
                        <Button size="sm" variant="secondary" onClick={() => handleSubmitReply(review.id)}>
                          Post
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};