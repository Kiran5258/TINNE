import React from 'react';
import { useProductStore } from '../services/useProductStore';
import { Button } from '../components/Button';
import { Link } from 'react-router-dom';
import { 
  IconTrendingUp, 
  IconDollarSign, 
  IconBox, 
  IconEdit, 
  IconTrash, 
  IconPlus 
} from '../components/Icons';

export const AdminDashboard: React.FC = () => {
  const { products, sales, deleteProduct } = useProductStore();

  const totalRevenue = sales.reduce((acc, sale) => acc + sale.amount, 0);
  const totalOrders = sales.length;

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      deleteProduct(id);
    }
  };

  const handleEdit = (id: string) => {
    // In a real app, navigate to /account/edit-product/:id
    alert(`Edit feature coming soon for product ID: ${id}`);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-neutral-900">Admin Dashboard</h1>
          <p className="text-neutral-500">Overview of sales and product inventory.</p>
        </div>
        <Link to="/account/add-product">
          <Button size="sm" className="flex items-center">
            <IconPlus className="w-4 h-4 mr-2" /> Add Product
          </Button>
        </Link>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-neutral-50 p-6 rounded-2xl border border-neutral-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-2 rounded-lg text-green-600">
              <IconDollarSign className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">+12%</span>
          </div>
          <p className="text-neutral-500 text-sm mb-1">Total Revenue</p>
          <p className="text-3xl font-display font-bold text-neutral-900">₹{totalRevenue.toLocaleString()}</p>
        </div>

        <div className="bg-neutral-50 p-6 rounded-2xl border border-neutral-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-2 rounded-lg text-blue-600">
              <IconBox className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-full">+5%</span>
          </div>
          <p className="text-neutral-500 text-sm mb-1">Total Orders</p>
          <p className="text-3xl font-display font-bold text-neutral-900">{totalOrders}</p>
        </div>

        <div className="bg-neutral-50 p-6 rounded-2xl border border-neutral-100">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-100 p-2 rounded-lg text-purple-600">
              <IconTrendingUp className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-neutral-400">Live</span>
          </div>
          <p className="text-neutral-500 text-sm mb-1">Active Products</p>
          <p className="text-3xl font-display font-bold text-neutral-900">{products.length}</p>
        </div>
      </div>

      {/* Recent Sales History */}
      <div className="mb-12">
        <h2 className="text-xl font-display font-bold text-neutral-900 mb-6">Recent Sales History</h2>
        <div className="bg-white rounded-2xl border border-neutral-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-neutral-50 text-neutral-500 border-b border-neutral-100">
                <tr>
                  <th className="px-6 py-4 font-medium">Order ID</th>
                  <th className="px-6 py-4 font-medium">Customer</th>
                  <th className="px-6 py-4 font-medium">Product</th>
                  <th className="px-6 py-4 font-medium">Date</th>
                  <th className="px-6 py-4 font-medium">Amount</th>
                  <th className="px-6 py-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {sales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-neutral-50 transition-colors">
                    <td className="px-6 py-4 font-bold text-brand-dark">{sale.id}</td>
                    <td className="px-6 py-4 text-neutral-600">{sale.customer}</td>
                    <td className="px-6 py-4 text-neutral-900">{sale.productTitle}</td>
                    <td className="px-6 py-4 text-neutral-500">{sale.date}</td>
                    <td className="px-6 py-4 font-bold">₹{sale.amount}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        sale.status === 'Completed' ? 'bg-green-100 text-green-700' :
                        sale.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {sale.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Product Management */}
      <div>
        <h2 className="text-xl font-display font-bold text-neutral-900 mb-6">Product Management</h2>
        <div className="bg-white rounded-2xl border border-neutral-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-neutral-50 text-neutral-500 border-b border-neutral-100">
                <tr>
                  <th className="px-6 py-4 font-medium">Image</th>
                  <th className="px-6 py-4 font-medium">Product Name</th>
                  <th className="px-6 py-4 font-medium">Category</th>
                  <th className="px-6 py-4 font-medium">Price</th>
                  <th className="px-6 py-4 font-medium">Stock Status</th>
                  <th className="px-6 py-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {products.map((product) => (
                  <tr key={product.id} className="hover:bg-neutral-50 transition-colors">
                    <td className="px-6 py-3">
                      <div className="w-12 h-12 rounded-lg bg-neutral-100 overflow-hidden">
                        <img src={product.image} alt="" className="w-full h-full object-cover" />
                      </div>
                    </td>
                    <td className="px-6 py-3 font-bold text-neutral-900">{product.title}</td>
                    <td className="px-6 py-3">
                      <span className="bg-neutral-100 text-neutral-600 px-2 py-1 rounded text-xs uppercase font-bold">
                        {product.category}
                      </span>
                    </td>
                    <td className="px-6 py-3">₹{product.price}</td>
                    <td className="px-6 py-3">
                      <span className={`text-xs font-bold ${product.inStock ? 'text-green-600' : 'text-red-500'}`}>
                        {product.inStock ? 'In Stock' : 'Out of Stock'}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button 
                          onClick={() => handleEdit(product.id)}
                          className="p-2 text-neutral-400 hover:text-brand-accent hover:bg-neutral-100 rounded-lg transition-colors"
                          title="Edit Product"
                        >
                          <IconEdit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(product.id)}
                          className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Product"
                        >
                          <IconTrash className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};