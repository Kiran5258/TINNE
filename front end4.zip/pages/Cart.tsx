import React from 'react';
import { Link } from 'react-router-dom';
import { useCartStore } from '../services/useCartStore';
import { Button } from '../components/Button';
import { IconTrash, IconArrowRight, IconMinus, IconPlus, IconBag } from '../components/Icons';

export const Cart: React.FC = () => {
  const { items, removeItem, updateQuantity, getCartTotal, clearCart } = useCartStore();
  const subtotal = getCartTotal();
  const shipping = subtotal > 1000 ? 0 : 80; // Free shipping over 1000
  const total = subtotal + shipping;

  if (items.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-white pt-20 px-6">
        <div className="w-24 h-24 bg-brand-muted rounded-full flex items-center justify-center mb-6 text-brand-dark/50">
          <IconBag className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-display font-bold text-neutral-900 mb-4">Your Bag is Empty</h1>
        <p className="text-neutral-500 mb-8 max-w-md text-center">
          It looks like you haven't added any luxury essentials to your cart yet.
        </p>
        <Link to="/products">
          <Button variant="primary" size="lg">Start Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20 min-h-screen bg-neutral-50">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-4xl font-display font-bold text-neutral-900 mb-8">Shopping Bag <span className="text-neutral-400 text-2xl font-normal ml-2">({items.length} items)</span></h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Cart Items List */}
          <div className="lg:col-span-2 space-y-6">
            {items.map((item) => (
              <div key={`${item.id}-${item.selectedSize}`} className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100 flex flex-col sm:flex-row gap-6 transition-all hover:shadow-md">
                <div className="w-full sm:w-32 h-32 bg-neutral-100 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-grow flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-brand-accent font-bold uppercase tracking-wider mb-1">{item.category}</p>
                      <h3 className="text-xl font-display font-bold text-neutral-900">{item.title}</h3>
                      <p className="text-sm text-neutral-500 mt-1">Size: {item.selectedSize}</p>
                    </div>
                    <p className="text-xl font-bold font-display text-neutral-900">₹{(item.price * item.quantity).toFixed(2)}</p>
                  </div>

                  <div className="flex justify-between items-end mt-6 sm:mt-0">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center border border-neutral-200 rounded-full px-2 py-1 bg-neutral-50">
                        <button 
                          onClick={() => updateQuantity(item.id, item.selectedSize, item.quantity - 1)}
                          className="p-1 hover:text-brand-accent transition-colors disabled:opacity-30"
                          disabled={item.quantity <= 1}
                        >
                          <IconMinus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.selectedSize, item.quantity + 1)}
                          className="p-1 hover:text-brand-accent transition-colors"
                        >
                          <IconPlus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => removeItem(item.id, item.selectedSize)}
                      className="text-neutral-400 hover:text-red-500 transition-colors flex items-center text-sm font-medium"
                    >
                      <IconTrash className="w-4 h-4 mr-1" /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}

            <div className="flex justify-between items-center pt-4">
              <Link to="/products" className="text-sm font-medium text-brand-dark flex items-center hover:underline">
                <IconArrowRight className="w-4 h-4 mr-2 rotate-180" /> Continue Shopping
              </Link>
              <button onClick={clearCart} className="text-sm text-neutral-400 hover:text-neutral-900">
                Clear Cart
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-neutral-100 sticky top-28">
              <h2 className="text-2xl font-display font-bold mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-neutral-600">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? <span className="text-green-600 font-medium">Free</span> : `₹${shipping.toFixed(2)}`}</span>
                </div>
                {shipping > 0 && (
                  <p className="text-xs text-neutral-400">Free shipping on orders over ₹1000</p>
                )}
              </div>
              
              <div className="border-t border-neutral-100 pt-6 mb-8">
                <div className="flex justify-between items-end">
                  <span className="text-lg font-bold text-neutral-900">Total</span>
                  <span className="text-3xl font-display font-bold text-brand-dark">₹{total.toFixed(2)}</span>
                </div>
                <p className="text-xs text-neutral-400 mt-2">Inclusive of all taxes</p>
              </div>

              <Button size="lg" className="w-full flex items-center justify-between group">
                Proceed to Checkout
                <IconArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </Button>

              <div className="mt-6 flex items-center justify-center gap-2 text-neutral-400">
                <div className="w-8 h-5 bg-neutral-200 rounded"></div>
                <div className="w-8 h-5 bg-neutral-200 rounded"></div>
                <div className="w-8 h-5 bg-neutral-200 rounded"></div>
                <span className="text-xs ml-2">Secure Payment</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};