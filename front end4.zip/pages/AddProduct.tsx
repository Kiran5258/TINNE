import React, { useState } from 'react';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { IconUpload, IconClose } from '../components/Icons';

export const AddProduct: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [sizes, setSizes] = useState<string[]>([]);
  const [currentSize, setCurrentSize] = useState('');
  
  // Simulating image upload state
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addSize = () => {
    if (currentSize && !sizes.includes(currentSize)) {
      setSizes([...sizes, currentSize]);
      setCurrentSize('');
    }
  };

  const removeSize = (s: string) => {
    setSizes(sizes.filter(size => size !== s));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API Post to /api/products
    setTimeout(() => {
      alert("Product added successfully!");
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold font-display mb-6">Add New Product</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input label="Product Title" placeholder="e.g. Organic Millet" required />
          <div className="w-full">
            <label className="block text-sm font-medium text-neutral-700 mb-1">Category</label>
            <select className="w-full px-4 py-3 rounded-xl border border-neutral-200 bg-neutral-50 focus:ring-2 focus:ring-brand-accent/50 outline-none">
              <option value="millets">Millets</option>
              <option value="nuts">Nuts & Seeds</option>
              <option value="rice">Rice</option>
              <option value="spices">Spices</option>
              <option value="pickles">Pickles</option>
            </select>
          </div>
        </div>

        <Input label="Price (₹)" type="number" step="0.01" required />

        {/* Sizes Chip Input */}
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-1">Available Sizes</label>
          <div className="flex gap-2 mb-2">
            <Input 
              value={currentSize} 
              onChange={(e) => setCurrentSize(e.target.value)} 
              placeholder="e.g. 500g" 
              className="!mb-0"
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSize())}
            />
            <Button type="button" onClick={addSize} variant="secondary">Add</Button>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {sizes.map(size => (
              <span key={size} className="bg-neutral-100 px-3 py-1 rounded-full text-sm flex items-center">
                {size}
                <button type="button" onClick={() => removeSize(size)} className="ml-2 text-neutral-400 hover:text-red-500">
                  <IconClose className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Rich Text Editor Simulation */}
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-1">Description</label>
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-neutral-50">
            <div className="bg-neutral-100 px-4 py-2 border-b border-neutral-200 text-xs text-neutral-500 flex gap-2">
              <span>B</span> <span>I</span> <span>U</span> {/* Placeholder toolbar */}
            </div>
            <textarea 
              className="w-full p-4 h-32 bg-transparent outline-none resize-none"
              placeholder="Product details..."
            ></textarea>
          </div>
        </div>

        {/* Image Upload */}
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-1">Product Image</label>
          <div className="border-2 border-dashed border-neutral-300 rounded-xl p-8 text-center hover:bg-neutral-50 transition-colors relative">
            {imagePreview ? (
              <div className="relative h-48 w-full">
                <img src={imagePreview} alt="Preview" className="h-full w-full object-contain" />
                <button 
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="absolute top-0 right-0 bg-white p-1 rounded-full shadow-md"
                >
                  <IconClose />
                </button>
              </div>
            ) : (
              <>
                <IconUpload className="w-8 h-8 mx-auto text-neutral-400 mb-2" />
                <p className="text-sm text-neutral-500">Click to upload or drag and drop</p>
                <input type="file" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
              </>
            )}
          </div>
        </div>

        <div className="pt-4">
          <Button type="submit" size="lg" className="w-full" isLoading={loading}>
            Save Product
          </Button>
        </div>
      </form>
    </div>
  );
};