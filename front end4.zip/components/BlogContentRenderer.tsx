import React from 'react';

interface ContentBlock {
  type: string;
  text?: string;
  level?: number;
  src?: string;
  caption?: string;
  items?: string[];
  value?: string;
}

interface BlogContentRendererProps {
  content: ContentBlock[];
}

export const BlogContentRenderer: React.FC<BlogContentRendererProps> = ({ content }) => {
  return (
    <div className="prose prose-lg prose-neutral max-w-none">
      {content.map((block, index) => {
        switch (block.type) {
          case 'heading':
            const Tag = `h${block.level || 2}` as React.ElementType;
            return (
              <Tag key={index} className="font-display font-bold text-neutral-900 mt-10 mb-4 text-2xl md:text-3xl">
                {block.text}
              </Tag>
            );
          
          case 'paragraph':
            return (
              <p key={index} className="text-lg text-neutral-600 leading-relaxed mb-6">
                {block.text}
              </p>
            );
          
          case 'image':
            return (
              <figure key={index} className="my-10 bg-neutral-50 rounded-2xl p-2 border border-neutral-100">
                <img 
                  src={block.src} 
                  alt={block.caption || 'Article image'} 
                  className="w-full rounded-xl shadow-sm" 
                  loading="lazy"
                />
                {block.caption && (
                  <figcaption className="text-center text-sm text-neutral-500 mt-3 italic font-medium">
                    {block.caption}
                  </figcaption>
                )}
              </figure>
            );
          
          case 'quote':
            return (
              <blockquote key={index} className="border-l-4 border-brand-accent pl-6 my-8 italic text-xl text-neutral-800 font-display">
                "{block.text}"
              </blockquote>
            );

          case 'list':
            return (
              <ul key={index} className="space-y-3 mb-8 ml-6 list-disc text-neutral-600 text-lg marker:text-brand-accent">
                {block.items?.map((item: string, i: number) => (
                  <li key={i} className="pl-2">{item}</li>
                ))}
              </ul>
            );
          
          case 'html':
            return (
              <div 
                key={index} 
                dangerouslySetInnerHTML={{ __html: block.value || '' }} 
                className="mb-8" 
              />
            );
            
          default:
            return null;
        }
      })}
    </div>
  );
};