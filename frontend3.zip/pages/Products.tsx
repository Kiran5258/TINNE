import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';
import { useProductStore } from '../services/useProductStore';
import { Reveal } from '../components/Reveal';

interface ProductsProps {
  category?: string;
}

const CATEGORIES = [
  { id: 'all', label: 'All Products', path: '/products' },
  { id: 'millet', label: 'Millets', path: '/products/millet' },
  { id: 'nuts', label: 'Nuts', path: '/products/nuts' },
  { id: 'rice', label: 'Rice', path: '/products/rice' },
  { id: 'spices', label: 'Spices', path: '/products/spices' }
];

export const Products: React.FC<ProductsProps> = ({ category: propCategory }) => {
  const { category: paramCategory } = useParams<{ category: string }>();
  const activeCategory = propCategory || paramCategory || 'all';
  const navigate = useNavigate();
  
  const { products: allProducts } = useProductStore();
  const [displayProducts, setDisplayProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Determine display title
  const getTitle = (cat: string) => {
    switch(cat) {
      case 'millet': return 'Ancient Millets';
      case 'nuts': return 'Premium Nuts';
      case 'rice': return 'Organic Rice';
      case 'spices': return 'Aromatic Spices';
      default: return 'All Products';
    }
  };

  useEffect(() => {
    setLoading(true);
    // Simulate slight delay for transition feel
    const timer = setTimeout(() => {
      let filtered = allProducts;
      if (activeCategory !== 'all') {
        filtered = allProducts.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());
      }
      setDisplayProducts(filtered);
      setLoading(false);
    }, 400);

    return () => clearTimeout(timer);
  }, [activeCategory, allProducts]);

  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Category Slider */}
        <div className="mb-12 overflow-x-auto no-scrollbar py-2 sticky top-20 z-10 bg-white/90 backdrop-blur-sm -mx-6 px-6">
          <div className="flex space-x-3 min-w-max">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => navigate(cat.path)}
                className={`px-6 py-3 rounded-full text-sm font-medium transition-all duration-300 border ${
                  (activeCategory === cat.id || (activeCategory === 'all' && cat.id === 'all'))
                    ? 'bg-brand-dark text-white border-brand-dark shadow-md transform scale-105' 
                    : 'bg-white text-neutral-600 border-neutral-200 hover:border-brand-accent hover:text-brand-dark'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <Reveal>
          <header className="mb-8">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-3 capitalize">
              {getTitle(activeCategory)}
            </h1>
            <p className="text-neutral-500 max-w-2xl">
              Browse our collection of ethically sourced, premium quality bulk ingredients.
            </p>
          </header>
        </Reveal>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
             {[1, 2, 3, 4, 5, 6].map(n => (
               <div key={n} className="h-96 bg-neutral-100 rounded-2xl animate-pulse"></div>
             ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {displayProducts.length > 0 ? (
              displayProducts.map((product, idx) => (
                <Reveal key={product.id} delay={idx * 50}>
                  <ProductCard product={product} />
                </Reveal>
              ))
            ) : (
              <div className="col-span-full py-20 text-center text-neutral-400">
                <p>No products found in this category.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};