import React from 'react';
import { Link } from 'react-router-dom';
import { IconArrowRight, IconBookOpen, IconFeather } from '../components/Icons';
import { Button } from '../components/Button';

const FEATURED_ARTICLES = [
  {
    id: 1,
    title: "The Quiet Luxury of Ancient Grains",
    subtitle: "Why millets are becoming the new global superfood",
    excerpt: "Once found in the humble grain jars of rural kitchens, millets are now taking center stage across elite wellness circles and luxury dining spaces. At Tinné, we explore how these ancient grains — naturally gluten-free and rich in micronutrients — are redefining modern nutrition.",
    image: "https://images.unsplash.com/photo-1546816570-36365b934b9d?auto=format&fit=crop&q=80&w=800",
    category: "Nutrition"
  },
  {
    id: 2,
    title: "Inside the Art of Cold-Pressed Spices",
    subtitle: "How slow extraction creates deeper aroma and purity",
    excerpt: "Cold-pressing is more than a technique; it’s a philosophy of patience. By preserving natural oils, enhancing fragrance, and avoiding heat damage, this method elevates traditional spices into gourmet-grade ingredients.",
    image: "https://images.unsplash.com/photo-1596208643924-f7c8702c2869?auto=format&fit=crop&q=80&w=800",
    category: "Craftsmanship"
  },
  {
    id: 3,
    title: "Traceability: The New Trust in Food",
    subtitle: "From farm soil to shelf — every pack tells a story",
    excerpt: "Modern consumers want more than taste; they want clarity. At Tinné, each product batch is logged, monitored, and audited using transparent sourcing protocols. We explore why traceability is becoming the new definition of luxury.",
    image: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&q=80&w=800",
    category: "Sustainability"
  },
  {
    id: 4,
    title: "The Revival of Heritage Pickles",
    subtitle: "Small-batch, sun-cured, and rooted in memory",
    excerpt: "Pickles are an art form — a delicate balance of spice, time, and sunlight. We dive into how Tinné blends old-world curing methods with contemporary hygiene standards to create pickles that feel both nostalgic and refined.",
    image: "https://images.unsplash.com/photo-1597362925123-77861d3fbac7?auto=format&fit=crop&q=80&w=800",
    category: "Tradition"
  }
];

export const Blog: React.FC = () => {
  return (
    <div className="pt-20 min-h-screen bg-neutral-50 font-sans">
      
      {/* Journal Header */}
      <header className="bg-white border-b border-neutral-100 py-24 px-6 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-dark via-brand-accent to-brand-dark"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="flex justify-center mb-6">
            <IconBookOpen className="w-8 h-8 text-brand-dark" />
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-neutral-900 mb-6">Tinné Journal</h1>
          <p className="text-xl md:text-2xl text-neutral-500 font-light tracking-wide mb-8">
            Exploring the Craft, Culture & Science Behind Heritage Foods
          </p>
          <p className="text-sm text-neutral-400 uppercase tracking-widest font-medium max-w-2xl mx-auto leading-relaxed">
            A modern editorial space where we uncover the stories, origins, and innovations shaping India’s finest traditional ingredients.
          </p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* Main Content - Featured Articles */}
        <div className="lg:col-span-8 space-y-16">
          <div className="flex items-center space-x-4 mb-8">
            <h2 className="text-2xl font-display font-bold text-neutral-900">Featured Stories</h2>
            <div className="h-px flex-1 bg-neutral-200"></div>
          </div>

          {FEATURED_ARTICLES.map((article) => (
            <article key={article.id} className="group bg-white rounded-2xl overflow-hidden shadow-sm border border-neutral-100 hover:shadow-xl transition-all duration-500">
              <div className="aspect-video w-full overflow-hidden relative">
                <img 
                  src={article.image} 
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute top-6 left-6 bg-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest text-brand-dark shadow-sm">
                  {article.category}
                </div>
              </div>
              <div className="p-8 md:p-10">
                <h3 className="text-3xl font-display font-bold text-neutral-900 mb-3 group-hover:text-brand-accent transition-colors">
                  {article.title}
                </h3>
                <p className="text-lg text-neutral-800 font-medium mb-4 italic font-display">
                  {article.subtitle}
                </p>
                <p className="text-neutral-600 leading-relaxed mb-8">
                  {article.excerpt}
                </p>
                <Link to={`/blog/${article.id}`}>
                  <Button variant="outline" className="group-hover:bg-brand-dark group-hover:text-white group-hover:border-brand-dark transition-all">
                    Read Story <IconArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </article>
          ))}
          
          {/* Pagination */}
          <div className="flex justify-center pt-8">
             <div className="flex space-x-2">
               <button className="w-10 h-10 rounded-full bg-brand-dark text-white font-bold flex items-center justify-center">1</button>
               <button className="w-10 h-10 rounded-full bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100 flex items-center justify-center">2</button>
               <button className="w-10 h-10 rounded-full bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100 flex items-center justify-center">3</button>
               <span className="w-10 h-10 flex items-center justify-center text-neutral-400">...</span>
             </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-4 space-y-12">
          
          {/* Latest Insights */}
          <div className="bg-white p-8 rounded-2xl border border-neutral-100 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <IconFeather className="w-5 h-5 text-brand-accent" />
              <h3 className="text-xl font-display font-bold">Latest Insights</h3>
            </div>
            <div className="space-y-6">
              <div className="group cursor-pointer">
                <h4 className="font-bold text-neutral-900 group-hover:text-brand-accent transition-colors mb-2">Why “Minimal Processing” Is the Future</h4>
                <p className="text-sm text-neutral-500">Understanding how gentle processing protects nutrition and texture.</p>
              </div>
              <div className="h-px bg-neutral-100"></div>
              <div className="group cursor-pointer">
                <h4 className="font-bold text-neutral-900 group-hover:text-brand-accent transition-colors mb-2">The Science Behind Rain-Fed Farming</h4>
                <p className="text-sm text-neutral-500">How low-impact cultivation enhances flavor and sustainability.</p>
              </div>
              <div className="h-px bg-neutral-100"></div>
              <div className="group cursor-pointer">
                <h4 className="font-bold text-neutral-900 group-hover:text-brand-accent transition-colors mb-2">Designing Packaging for Modern Heritage</h4>
                <p className="text-sm text-neutral-500">A look into the balance of storytelling and sustainability.</p>
              </div>
            </div>
          </div>

          {/* Editor's Note */}
          <div className="bg-neutral-900 text-white p-8 rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <IconFeather className="w-24 h-24" />
            </div>
            <span className="text-brand-accent uppercase tracking-widest text-xs font-bold mb-4 block">From the Editor</span>
            <p className="font-display text-xl font-medium mb-6 leading-relaxed relative z-10">
              "We believe that luxury is not in excess, but in intentionality. And every story we publish reflects that philosophy."
            </p>
            <p className="text-neutral-400 text-sm">
              — The Tinné Editorial Team
            </p>
          </div>

          {/* Categories */}
          <div className="bg-white p-8 rounded-2xl border border-neutral-100 shadow-sm">
             <h3 className="text-lg font-bold font-display mb-6">Explore Topics</h3>
             <div className="flex flex-wrap gap-2">
               {['Sustainability', 'Recipes', 'Heritage', 'Wellness', 'Farming', 'Design'].map(tag => (
                 <span key={tag} className="px-3 py-1 bg-neutral-50 border border-neutral-200 rounded-full text-xs font-medium text-neutral-600 hover:bg-brand-dark hover:text-white hover:border-brand-dark transition-colors cursor-pointer">
                   {tag}
                 </span>
               ))}
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};