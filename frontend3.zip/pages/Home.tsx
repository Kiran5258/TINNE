import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { IconArrowRight, IconChevronLeft, IconChevronRight } from '../components/Icons';
import { ProductCard } from '../components/ProductCard';
import { useProductStore } from '../services/useProductStore';
import { Reveal } from '../components/Reveal';

const CATEGORIES = [
  { id: 'millet', label: 'Millets', path: '/products/millet', image: 'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95' },
  { id: 'nuts', label: 'Nuts', path: '/products/nuts', image: 'https://images.unsplash.com/photo-1596208643924-f7c8702c2869?auto=format&fit=crop&q=80&w=400' },
  { id: 'rice', label: 'Rice', path: '/products/rice', image: 'https://aistudiocdn.com/d/f3af9610-c020-4357-96a6-f2b74070a248' },
  { id: 'spices', label: 'Spices', path: '/products/spices', image: 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?auto=format&fit=crop&q=80&w=400' },
];

const BLOG_POSTS = [
  {
    id: 1,
    title: "The Revival of Ancient Grains",
    excerpt: "Why millets are making a comeback in modern Indian kitchens.",
    date: "Oct 12, 2023",
    image: "https://images.unsplash.com/photo-1486328228599-85db4443971f?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: 2,
    title: "Understanding Organic Certification",
    excerpt: "What it really means when you buy 'Certified Organic'.",
    date: "Oct 08, 2023",
    image: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: 3,
    title: "Spices as Medicine",
    excerpt: "Traditional Ayurvedic benefits of common kitchen spices.",
    date: "Sep 28, 2023",
    image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&q=80&w=400"
  }
];

const HERO_IMAGES = [
  'https://aistudiocdn.com/d/f3af9610-c020-4357-96a6-f2b74070a248', // Rice top view
  'https://aistudiocdn.com/d/ef70b686-e91b-4f91-817e-7bf33f019054', // Biriyani Rice Pack
  'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95', // Millets Pack
];

export const Home: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { products } = useProductStore();

  const featuredProducts = products.slice(0, 4);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % HERO_IMAGES.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + HERO_IMAGES.length) % HERO_IMAGES.length);

  return (
    <div className="w-full pt-20">
      {/* Hero Slider */}
      <section className="relative h-[calc(100vh-5rem)] min-h-[600px] w-full overflow-hidden bg-neutral-900">
        {HERO_IMAGES.map((img, index) => (
          <div 
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img 
              src={img} 
              alt={`Slide ${index + 1}`} 
              className="w-full h-full object-cover opacity-90 animate-slow-zoom"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />
          </div>
        ))}

        <div className="absolute inset-0 flex flex-col justify-center items-center text-center px-6 z-20">
          <Reveal delay={100} duration={1000} direction="down">
            <h1 className="font-script text-7xl md:text-9xl text-white mb-6 drop-shadow-lg opacity-95">
              Tinné
            </h1>
          </Reveal>
          <Reveal delay={300} duration={1000}>
            <p className="text-xl md:text-3xl text-neutral-100 font-light tracking-[0.2em] uppercase mb-10 drop-shadow-md border-t border-b border-white/30 py-4 px-8 backdrop-blur-sm bg-white/5">
              From Grandma's Thinnai
            </p>
          </Reveal>
          <Reveal delay={500} duration={1000} direction="up">
            <div className="flex gap-4">
              <Button variant="primary" size="lg" className="bg-brand-accent text-brand-dark hover:bg-white hover:text-brand-dark border-none min-w-[160px] transform hover:scale-105 transition-transform">
                <Link to="/products">Shop Now</Link>
              </Button>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-brand-dark min-w-[160px] transform hover:scale-105 transition-transform">
                <Link to="/about">Our Story</Link>
              </Button>
            </div>
          </Reveal>
        </div>

        <button 
          onClick={prevSlide}
          className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 backdrop-blur-md p-4 rounded-full text-white transition-all z-20 border border-white/20 hidden md:block hover:scale-110"
        >
          <IconChevronLeft className="w-6 h-6" />
        </button>
        <button 
          onClick={nextSlide}
          className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 backdrop-blur-md p-4 rounded-full text-white transition-all z-20 border border-white/20 hidden md:block hover:scale-110"
        >
          <IconChevronRight className="w-6 h-6" />
        </button>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex space-x-4 z-20">
          {HERO_IMAGES.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                index === currentSlide ? 'bg-brand-accent w-12' : 'bg-white/50 w-3 hover:bg-white'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Product Showcases & Categories */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal className="flex justify-between items-end mb-16">
            <div className="max-w-xl">
              <h2 className="text-4xl font-display font-bold text-neutral-900 mb-3">Product Showcases</h2>
              <div className="h-1 w-20 bg-brand-accent mb-4"></div>
              <p className="text-neutral-500 text-lg">Curated collections handpicked for exceptional quality, purity, and freshness directly from the source.</p>
            </div>
            <Link to="/products" className="hidden md:flex items-center text-brand-dark font-bold hover:text-brand-accent transition-colors border-b-2 border-transparent hover:border-brand-accent pb-1">
              View All Collection <IconArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Reveal>

          {/* Row 1: Products */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12 mb-24">
            {featuredProducts.map((product, idx) => (
              <Reveal key={product.id} delay={idx * 100}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
          
          {/* Row 2: Category Shortcuts */}
          <div className="mb-8">
            <Reveal className="text-center mb-10">
               <span className="text-brand-accent font-bold tracking-wider uppercase text-sm">Discover by Category</span>
               <h3 className="text-2xl font-display font-bold text-neutral-900 mt-2">Essential Ingredients</h3>
            </Reveal>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {CATEGORIES.map((cat, idx) => (
                <Reveal key={cat.id} delay={idx * 100}>
                  <Link 
                    to={cat.path}
                    className="group relative h-64 rounded-2xl overflow-hidden cursor-pointer shadow-sm hover:shadow-2xl transition-all duration-500 block transform hover:-translate-y-2"
                  >
                    <img 
                      src={cat.image} 
                      alt={cat.label}
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform transition-transform duration-500 group-hover:-translate-y-2">
                      <p className="font-display font-bold text-2xl mb-1">{cat.label}</p>
                      <div className="h-0.5 w-12 bg-brand-accent mb-3 transition-all duration-500 group-hover:w-full"></div>
                      <span className="text-xs font-medium uppercase tracking-widest flex items-center opacity-0 group-hover:opacity-100 transition-opacity delay-100">
                        Explore <IconArrowRight className="w-4 h-4 ml-2" />
                      </span>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
          
          <div className="mt-12 text-center md:hidden">
             <Link to="/products">
              <Button variant="outline">View All Products</Button>
             </Link>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-24 bg-neutral-50 border-t border-neutral-100">
        <div className="max-w-7xl mx-auto px-6">
          <Reveal className="flex justify-between items-end mb-12">
             <div>
               <h2 className="text-3xl font-display font-bold text-neutral-900">From the Journal</h2>
               <p className="text-neutral-500 mt-2">Stories of heritage, health, and sustainable living.</p>
             </div>
             <Link to="/blog" className="hidden md:inline-flex items-center text-brand-dark font-medium hover:text-brand-accent transition-colors">
               Read All Articles <IconArrowRight className="ml-2 w-4 h-4" />
             </Link>
          </Reveal>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post, idx) => (
              <Reveal key={post.id} delay={idx * 150}>
                <Link to="/blog" className="block h-full">
                  <article className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-500 h-full flex flex-col cursor-pointer">
                    <div className="relative h-56 overflow-hidden">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-neutral-900">
                        {post.date}
                      </div>
                    </div>
                    <div className="p-8 flex flex-col flex-grow">
                      <h3 className="text-xl font-display font-bold text-neutral-900 mb-3 group-hover:text-brand-accent transition-colors leading-snug">
                        {post.title}
                      </h3>
                      <p className="text-neutral-600 text-sm line-clamp-2 mb-6 leading-relaxed flex-grow">
                        {post.excerpt}
                      </p>
                      <div className="text-sm font-bold text-brand-dark flex items-center uppercase tracking-wide group-hover:underline">
                        Read Story <IconArrowRight className="w-3 h-3 ml-1 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  </article>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};