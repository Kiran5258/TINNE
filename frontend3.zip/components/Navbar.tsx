import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { IconBag, IconUser, IconSearch, IconMenu, IconClose } from './Icons';
import { useAuthStore } from '../services/useAuthStore';
import { useCartStore } from '../services/useCartStore';

export const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated } = useAuthStore();
  const { getCartCount } = useCartStore();
  const location = useLocation();
  const cartCount = getCartCount();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled || isMenuOpen ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-white shadow-sm py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        
        {/* Logo */}
        <Link to="/" className="flex flex-col leading-none z-50 relative group">
          <span className="text-3xl font-script font-bold text-brand-dark tracking-wide transform transition-transform group-hover:scale-105 origin-left">Tinné</span>
          <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-sans">From Grandma's Thinnai</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <NavLink to="/">Home</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/blog">Blog</NavLink>
          <NavLink to="/products">Products</NavLink>
        </div>

        {/* Right Actions */}
        <div className="hidden md:flex items-center space-x-6">
          <div className="relative group">
            <IconSearch className="w-5 h-5 text-neutral-600 group-hover:text-neutral-900 cursor-pointer transition-colors" />
          </div>
          <Link to={isAuthenticated ? "/account" : "/login"}>
             <IconUser className="w-5 h-5 text-neutral-600 hover:text-neutral-900 transition-colors" />
          </Link>
          <Link to="/cart" className="relative group">
            <IconBag className="w-5 h-5 text-neutral-600 group-hover:text-neutral-900 transition-colors" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-brand-accent text-brand-dark text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full animate-bounce-short shadow-sm">
                {cartCount}
              </span>
            )}
          </Link>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden z-50 relative p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <IconClose /> : <IconMenu />}
        </button>

        {/* Mobile Slide-over */}
        <div className={`fixed inset-0 bg-white z-40 transform transition-transform duration-500 ease-in-out md:hidden flex flex-col pt-32 px-8 ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}>
          <div className="flex flex-col space-y-6 text-2xl font-display font-medium">
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/blog">Blog</Link>
            <Link to="/products">Products</Link>
            <div className="h-px bg-neutral-100 w-full my-4" />
            <Link to="/cart" className="flex items-center justify-between">
              Cart <span className="text-sm bg-neutral-100 px-2 py-1 rounded-full">{cartCount}</span>
            </Link>
            <Link to={isAuthenticated ? "/account" : "/login"} className="text-lg text-neutral-600">
              {isAuthenticated ? 'My Account' : 'Log In / Sign Up'}
            </Link>
          </div>
        </div>

      </div>
    </nav>
  );
};

const NavLink: React.FC<{ to: string; children: React.ReactNode }> = ({ to, children }) => {
  return (
    <Link 
      to={to} 
      className="text-sm font-medium text-neutral-600 hover:text-neutral-900 transition-colors relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-[2px] after:bg-brand-accent after:transition-all after:duration-300 hover:after:w-full"
    >
      {children}
    </Link>
  );
};