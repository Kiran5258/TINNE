import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { Button } from './Button';
import { IconBag, IconCheck } from './Icons';
import { useCartStore } from '../services/useCartStore';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addItem } = useCartStore();
  const [added, setAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation when clicking the button
    addItem(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <article className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 hover:shadow-xl hover:border-brand-accent/30 transition-all duration-500 flex flex-col h-full transform hover:-translate-y-2">
      <Link to={`/product/${product.id}`} className="relative aspect-[4/3] overflow-hidden bg-neutral-100 block">
        <img 
          src={product.image} 
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-500" />
        {!product.inStock && (
          <div className="absolute top-2 right-2 bg-neutral-900 text-white text-xs px-2 py-1 rounded-full">
            Out of Stock
          </div>
        )}
      </Link>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-2">
          <span className="text-xs uppercase tracking-wider text-neutral-500 font-medium group-hover:text-brand-accent transition-colors">{product.category}</span>
        </div>
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-lg font-display font-semibold text-neutral-900 mb-2 leading-snug group-hover:text-brand-dark transition-colors">
            {product.title}
          </h3>
        </Link>
        <p className="text-sm text-neutral-600 line-clamp-2 mb-4 flex-grow">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-neutral-100 group-hover:border-neutral-200 transition-colors">
          <span className="text-xl font-bold font-display text-neutral-900">
            ₹{product.price.toFixed(2)}
          </span>
          <Button 
            size="sm" 
            variant={added ? "primary" : "secondary"} 
            className={`!p-2.5 transition-all duration-300 transform group-hover:scale-105 ${added ? "bg-green-600 hover:bg-green-700" : ""}`}
            onClick={handleAddToCart}
            disabled={!product.inStock}
          >
            {added ? <IconCheck className="w-5 h-5 text-white" /> : <IconBag className="w-5 h-5" />}
            <span className="sr-only">Add to cart</span>
          </Button>
        </div>
      </div>
    </article>
  );
};