import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ProtectedRoute } from './components/ProtectedRoute';

// Pages
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Products } from './pages/Products';
import { ProductDetails } from './pages/ProductDetails';
import { AddProduct } from './pages/AddProduct';
import { About } from './pages/About';
import { Blog } from './pages/Blog';
import { Cart } from './pages/Cart';
import { Profile } from './pages/Profile';
import { AdminDashboard } from './pages/AdminDashboard';
import { AccountLayout } from './layouts/AccountLayout';

// Placeholder components for routes not fully detailed in request but required for completeness
const PlaceholderPage: React.FC<{title: string}> = ({title}) => (
  <div className="pt-32 pb-20 text-center min-h-[50vh]">
    <h1 className="text-3xl font-display font-bold mb-4">{title}</h1>
    <p className="text-neutral-500">Content coming soon.</p>
  </div>
);

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/about" element={<About />} />
            <Route path="/cart" element={<Cart />} />

            {/* Product Routes */}
            <Route path="/products" element={<Products category="all" />} />
            <Route path="/products/millet" element={<Products category="millet" />} />
            <Route path="/products/nuts" element={<Products category="nuts" />} />
            <Route path="/products/rice" element={<Products category="rice" />} />
            <Route path="/products/spices" element={<Products category="spices" />} />
            <Route path="/products/pickles" element={<Products category="pickles" />} />
            <Route path="/product/:id" element={<ProductDetails />} />

            {/* Protected Account Routes */}
            <Route path="/account" element={<ProtectedRoute><AccountLayout /></ProtectedRoute>}>
              <Route index element={<Navigate to="profile" replace />} />
              <Route path="profile" element={<Profile />} />
              <Route path="orders" element={<PlaceholderPage title="Order History" />} />
              <Route path="addresses" element={<PlaceholderPage title="Saved Addresses" />} />
              <Route path="admin" element={<AdminDashboard />} />
              <Route path="add-product" element={<AddProduct />} />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;