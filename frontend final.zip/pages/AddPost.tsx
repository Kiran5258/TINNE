import React, { useState } from 'react';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { IconUpload, IconClose } from '../components/Icons';

export const AddPost: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    excerpt: '',
    content: ''
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API Post
    setTimeout(() => {
      alert("Post published successfully!");
      setLoading(false);
      setFormData({ title: '', category: '', excerpt: '', content: '' });
      setImagePreview(null);
    }, 1000);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold font-display mb-8">Create New Journal Entry</h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Input 
              label="Article Title" 
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="e.g. The Revival of Red Millet" 
              required 
            />
            
            <div className="w-full">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Category</label>
              <select 
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 bg-neutral-50 focus:ring-2 focus:ring-brand-accent/50 outline-none"
                required
              >
                <option value="">Select Category</option>
                <option value="Field Notes from Indian Farms">Field Notes from Indian Farms</option>
                <option value="Rituals & Recipes">Rituals & Recipes</option>
                <option value="People Who Shape Our Brand">People Who Shape Our Brand</option>
                <option value="Backed by Science">Backed by Science</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Excerpt</label>
              <textarea 
                name="excerpt"
                value={formData.excerpt}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 bg-neutral-50 focus:ring-2 focus:ring-brand-accent/50 outline-none h-32 resize-none"
                placeholder="Short summary for preview cards..."
                required
              />
            </div>
          </div>

          <div>
             <label className="block text-sm font-medium text-neutral-700 mb-1">Hero Image</label>
             <div className="border-2 border-dashed border-neutral-300 rounded-xl p-8 text-center hover:bg-neutral-50 transition-colors relative h-64 flex flex-col items-center justify-center">
              {imagePreview ? (
                <div className="absolute inset-0 p-2">
                  <img src={imagePreview} alt="Preview" className="h-full w-full object-cover rounded-lg" />
                  <button 
                    type="button"
                    onClick={() => setImagePreview(null)}
                    className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-md text-neutral-600 hover:text-red-500"
                  >
                    <IconClose className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <>
                  <IconUpload className="w-10 h-10 mx-auto text-neutral-400 mb-3" />
                  <p className="text-sm text-neutral-500 font-medium">Click to upload hero image</p>
                  <p className="text-xs text-neutral-400 mt-1">SVG, PNG, JPG or GIF (max. 2MB)</p>
                  <input type="file" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </>
              )}
            </div>
          </div>
        </div>

        {/* Content Editor Simulation */}
        <div>
          <label className="block text-sm font-medium text-neutral-700 mb-1">Article Content</label>
          <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white">
            <div className="bg-neutral-50 px-4 py-3 border-b border-neutral-200 text-sm text-neutral-600 flex gap-4 font-medium">
              <button type="button" className="hover:text-brand-dark">Bold</button>
              <button type="button" className="hover:text-brand-dark">Italic</button>
              <button type="button" className="hover:text-brand-dark">Heading</button>
              <button type="button" className="hover:text-brand-dark">Quote</button>
              <button type="button" className="hover:text-brand-dark">List</button>
            </div>
            <textarea 
              name="content"
              value={formData.content}
              onChange={handleChange}
              className="w-full p-6 h-96 bg-transparent outline-none resize-none font-mono text-sm leading-relaxed"
              placeholder="Write your story here... (Markdown supported)"
            ></textarea>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-neutral-100">
          <Button type="submit" size="lg" className="min-w-[200px]" isLoading={loading}>
            Publish Article
          </Button>
        </div>
      </form>
    </div>
  );
};