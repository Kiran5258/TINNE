
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { useAuthStore } from '../services/useAuthStore';
import { validateEmail, validatePassword, validateRequired } from '../utils/validation';

export const Signup: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState<any>({});
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: any = {};
    
    if (!validateRequired(formData.name)) newErrors.name = 'Name is required';
    if (!validateEmail(formData.email)) newErrors.email = 'Invalid email address';
    if (!validatePassword(formData.password)) newErrors.password = 'Password must be 8+ chars with a number';
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setLoading(true);
      // Simulate API call
      setTimeout(() => {
        login({
          id: '2',
          name: formData.name,
          email: formData.email,
          role: 'user'
        }, 'mock-jwt-token');
        setLoading(false);
        // Navigate to the next step: Registration Details
        navigate('/register');
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-3xl shadow-sm">
        <div className="text-center">
          <h2 className="text-3xl font-display font-bold text-neutral-900">Create Account</h2>
          <p className="mt-2 text-sm text-neutral-600">
            Step 1 of 2: Account Credentials
          </p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
             <Input 
              label="Full Name"
              name="name"
              type="text" 
              value={formData.name}
              onChange={handleChange}
              error={errors.name}
              placeholder="Enter your full name"
            />
            <Input 
              label="Email address"
              name="email"
              type="email" 
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
              placeholder="you@example.com"
            />
            <Input 
              label="Password"
              name="password"
              type="password" 
              value={formData.password}
              onChange={handleChange}
              error={errors.password}
              placeholder="••••••••"
            />
             <Input 
              label="Confirm Password"
              name="confirmPassword"
              type="password" 
              value={formData.confirmPassword}
              onChange={handleChange}
              error={errors.confirmPassword}
              placeholder="••••••••"
            />
          </div>

          <Button type="submit" className="w-full" isLoading={loading}>
            Continue
          </Button>

          <div className="text-center text-sm">
            Already have an account? <Link to="/login" className="font-medium text-brand-accent hover:text-yellow-600">Log in</Link>
          </div>
        </form>
      </div>
    </div>
  );
};
