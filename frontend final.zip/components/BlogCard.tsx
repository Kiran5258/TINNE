import React from 'react';
import { Link } from 'react-router-dom';
import { IconArrowRight, IconCalendar, IconClock } from './Icons';
import { BlogPost } from '../types';

interface BlogCardProps {
  post: BlogPost;
  compact?: boolean;
}

export const BlogCard: React.FC<BlogCardProps> = ({ post, compact = false }) => {
  return (
    <article className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-500 h-full flex flex-col">
      <Link 
        to={`/blog/${post.slug}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className={`relative overflow-hidden flex-shrink-0 block ${compact ? 'h-48' : 'h-56'}`}
      >
        <img 
          src={post.image} 
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-neutral-900 shadow-sm border border-neutral-100">
          {post.category}
        </div>
      </Link>
      
      <div className={`flex flex-col flex-grow ${compact ? 'p-5' : 'p-8'}`}>
        {!compact && (
          <div className="flex items-center text-xs text-neutral-400 mb-3 space-x-3">
             <div className="flex items-center">
               <IconCalendar className="w-3 h-3 mr-1" />
               {post.publishedAt}
             </div>
             <div className="flex items-center">
               <IconClock className="w-3 h-3 mr-1" />
               {post.readingTime}
             </div>
          </div>
        )}

        <h3 className={`${compact ? 'text-lg' : 'text-xl'} font-display font-bold text-neutral-900 mb-3 group-hover:text-brand-accent transition-colors leading-snug`}>
          <Link to={`/blog/${post.slug}`} target="_blank" rel="noopener noreferrer">
            {post.title}
          </Link>
        </h3>
        
        <p className="text-neutral-600 text-sm line-clamp-2 mb-6 leading-relaxed flex-grow">
          {post.excerpt}
        </p>
        
        <Link 
          to={`/blog/${post.slug}`} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-sm font-bold text-brand-dark flex items-center group-hover:underline uppercase tracking-wide mt-auto"
        >
          Read Full Story <IconArrowRight className="w-3 h-3 ml-1 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    </article>
  );
};