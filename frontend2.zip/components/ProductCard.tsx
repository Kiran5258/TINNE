import React from 'react';
import { Product } from '../types';
import { Button } from './Button';
import { IconBag } from './Icons';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <article className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 hover:shadow-lg transition-all duration-300 flex flex-col h-full">
      <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100">
        <img 
          src={product.image} 
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
        />
        {!product.inStock && (
          <div className="absolute top-2 right-2 bg-neutral-900 text-white text-xs px-2 py-1 rounded-full">
            Out of Stock
          </div>
        )}
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-2">
          <span className="text-xs uppercase tracking-wider text-neutral-500 font-medium">{product.category}</span>
        </div>
        <h3 className="text-lg font-display font-semibold text-neutral-900 mb-2 leading-snug group-hover:text-brand-accent transition-colors">
          {product.title}
        </h3>
        <p className="text-sm text-neutral-600 line-clamp-2 mb-4 flex-grow">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-neutral-100">
          <span className="text-xl font-bold font-display text-neutral-900">
            ₹{product.price.toFixed(2)}
          </span>
          <Button size="sm" variant="secondary" className="!p-2.5">
            <IconBag className="w-5 h-5" />
            <span className="sr-only">Add to cart</span>
          </Button>
        </div>
      </div>
    </article>
  );
};