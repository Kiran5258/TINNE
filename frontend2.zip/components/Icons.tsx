import React from 'react';
import { 
  ShoppingBag, 
  User, 
  Search, 
  Menu, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  ArrowRight,
  Plus,
  Upload,
  LogOut,
  MapPin,
  Box,
  Leaf,
  ShieldCheck,
  Globe,
  Award,
  Heart,
  BookOpen,
  Feather
} from 'lucide-react';

export const IconBag = ({ className }: { className?: string }) => <ShoppingBag className={className} />;
export const IconUser = ({ className }: { className?: string }) => <User className={className} />;
export const IconSearch = ({ className }: { className?: string }) => <Search className={className} />;
export const IconMenu = ({ className }: { className?: string }) => <Menu className={className} />;
export const IconClose = ({ className }: { className?: string }) => <X className={className} />;
export const IconChevronRight = ({ className }: { className?: string }) => <ChevronRight className={className} />;
export const IconChevronLeft = ({ className }: { className?: string }) => <ChevronLeft className={className} />;
export const IconArrowRight = ({ className }: { className?: string }) => <ArrowRight className={className} />;
export const IconPlus = ({ className }: { className?: string }) => <Plus className={className} />;
export const IconUpload = ({ className }: { className?: string }) => <Upload className={className} />;
export const IconLogout = ({ className }: { className?: string }) => <LogOut className={className} />;
export const IconMapPin = ({ className }: { className?: string }) => <MapPin className={className} />;
export const IconBox = ({ className }: { className?: string }) => <Box className={className} />;
export const IconLeaf = ({ className }: { className?: string }) => <Leaf className={className} />;
export const IconShieldCheck = ({ className }: { className?: string }) => <ShieldCheck className={className} />;
export const IconGlobe = ({ className }: { className?: string }) => <Globe className={className} />;
export const IconAward = ({ className }: { className?: string }) => <Award className={className} />;
export const IconHeart = ({ className }: { className?: string }) => <Heart className={className} />;
export const IconBookOpen = ({ className }: { className?: string }) => <BookOpen className={className} />;
export const IconFeather = ({ className }: { className?: string }) => <Feather className={className} />;