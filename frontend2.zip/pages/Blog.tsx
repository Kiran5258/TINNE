import React from 'react';
import { IconArrowRight, IconBookOpen, IconFeather } from '../components/Icons';
import { Link } from 'react-router-dom';

const FEATURED_ARTICLES = [
  {
    id: 1,
    category: 'Ingredient Spotlight',
    title: 'The Quiet Luxury of Ancient Grains',
    subtitle: 'Why millets are becoming the new global superfood',
    excerpt: 'Once found in the humble grain jars of rural kitchens, millets are now taking center stage across elite wellness circles and luxury dining spaces. At Tinné, we explore how these ancient grains are redefining modern nutrition.',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=800',
    link: '#'
  },
  {
    id: 2,
    category: 'Process & Craft',
    title: 'Inside the Art of Cold-Pressed Spices',
    subtitle: 'How slow extraction creates deeper aroma and purity',
    excerpt: 'Cold-pressing is more than a technique; it’s a philosophy of patience. By preserving natural oils and avoiding heat damage, this method elevates traditional spices into gourmet-grade ingredients.',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=800',
    link: '#'
  },
  {
    id: 3,
    category: 'Sustainability',
    title: 'Traceability: The New Trust in Food',
    subtitle: 'From farm soil to shelf — every pack tells a story',
    excerpt: 'Modern consumers want more than taste; they want clarity. At Tinné, each product batch is logged, monitored, and audited using transparent sourcing protocols. Traceability is the new definition of luxury.',
    image: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80&w=800',
    link: '#'
  },
  {
    id: 4,
    category: 'Culinary Heritage',
    title: 'The Revival of Heritage Pickles',
    subtitle: 'Small-batch, sun-cured, and rooted in memory',
    excerpt: 'Pickles are an art form — a delicate balance of spice, time, and sunlight. We dive into how Tinné blends old-world curing methods with contemporary hygiene to create pickles that feel both nostalgic and refined.',
    image: 'https://images.unsplash.com/photo-1589135233689-d9774619d854?auto=format&fit=crop&q=80&w=800',
    link: '#'
  }
];

const INSIGHTS = [
  {
    id: 1,
    title: 'Why "Minimal Processing" Is the Future of Premium Foods',
    desc: 'Understanding how gentle processing protects nutrition, texture, and authenticity in a world of ultra-fast manufacturing.'
  },
  {
    id: 2,
    title: 'The Science Behind Rain-Fed Farming',
    desc: 'How low-impact cultivation enhances flavor, sustainability, and soil health.'
  },
  {
    id: 3,
    title: 'Designing Packaging for Modern Heritage Foods',
    desc: 'A look into the balance of storytelling, sustainability, and luxury aesthetics.'
  }
];

export const Blog: React.FC = () => {
  return (
    <div className="pt-20 min-h-screen bg-white">
      
      {/* Journal Header */}
      <header className="bg-neutral-50 py-24 px-6 border-b border-neutral-100">
        <div className="max-w-4xl mx-auto text-center">
          <span className="block font-script text-4xl text-brand-accent mb-4">Tinné Journal</span>
          <h1 className="text-4xl md:text-6xl font-display font-bold text-neutral-900 mb-6 leading-tight">
            Exploring the Craft, Culture & Science Behind Heritage Foods
          </h1>
          <p className="text-xl text-neutral-600 font-light max-w-2xl mx-auto leading-relaxed">
            A modern editorial space where we uncover the stories, origins, and innovations shaping India’s finest traditional ingredients.
          </p>
        </div>
      </header>

      {/* Featured Articles Grid */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="flex items-center space-x-4 mb-12">
          <IconBookOpen className="w-6 h-6 text-brand-accent" />
          <h2 className="text-2xl font-display font-bold text-neutral-900">Featured Articles</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
          {FEATURED_ARTICLES.map((article) => (
            <article key={article.id} className="group cursor-pointer">
              <div className="overflow-hidden rounded-2xl mb-6 aspect-[16/9] shadow-sm">
                <img 
                  src={article.image} 
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="space-y-3">
                <span className="text-xs font-bold tracking-widest uppercase text-brand-accent">
                  {article.category}
                </span>
                <h3 className="text-3xl font-display font-bold text-neutral-900 group-hover:text-brand-dark transition-colors">
                  {article.title}
                </h3>
                <p className="text-lg font-medium text-neutral-800 italic">
                  {article.subtitle}
                </p>
                <p className="text-neutral-600 leading-relaxed">
                  {article.excerpt}
                </p>
                <div className="pt-2">
                  <span className="inline-flex items-center text-sm font-bold text-brand-dark uppercase tracking-wide group-hover:underline">
                    Read Story <IconArrowRight className="w-4 h-4 ml-2" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Latest Insights & Editor's Note */}
      <section className="bg-neutral-900 text-white py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-12 gap-16">
            
            {/* Insights Column */}
            <div className="md:col-span-7">
              <h3 className="text-3xl font-display font-bold mb-10 border-b border-neutral-800 pb-6">
                Latest Insights
              </h3>
              <div className="space-y-10">
                {INSIGHTS.map((insight) => (
                  <div key={insight.id} className="group cursor-pointer hover:bg-neutral-800/50 p-6 -mx-6 rounded-2xl transition-colors">
                    <h4 className="text-xl font-bold text-brand-accent mb-2 group-hover:text-white transition-colors">
                      {insight.title}
                    </h4>
                    <p className="text-neutral-400 font-light leading-relaxed">
                      {insight.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Editor's Note Column */}
            <div className="md:col-span-5">
              <div className="bg-brand-muted text-neutral-900 p-10 rounded-3xl relative overflow-hidden">
                <IconFeather className="w-12 h-12 text-brand-accent mb-6" />
                <h3 className="text-2xl font-display font-bold mb-6">From the Editor</h3>
                <div className="space-y-4 text-neutral-700 leading-relaxed">
                  <p>
                    At Tinné, our journal is more than a blog — it is a curated collection of ideas, stories, and research that reconnect heritage with modern living.
                  </p>
                  <p className="font-medium italic">
                    We believe that luxury is not in excess, but in intentionality.
                  </p>
                  <p>
                    And every story we publish reflects that philosophy.
                  </p>
                </div>
                <div className="mt-8 pt-6 border-t border-neutral-200">
                  <img 
                    src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100" 
                    alt="Editor" 
                    className="w-12 h-12 rounded-full mb-3 object-cover"
                  />
                  <p className="text-sm font-bold">Sarah V.</p>
                  <p className="text-xs text-neutral-500 uppercase tracking-wider">Head of Content</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="py-24 px-6 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-display font-bold mb-6">Join the Conversation</h2>
          <p className="text-neutral-600 mb-8">
            Subscribe to receive our latest stories, recipes, and product launches directly to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="px-6 py-4 bg-neutral-50 border border-neutral-200 rounded-full w-full sm:w-80 focus:outline-none focus:ring-2 focus:ring-brand-accent/50"
            />
            <button className="px-8 py-4 bg-brand-dark text-white rounded-full font-bold hover:bg-neutral-800 transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};