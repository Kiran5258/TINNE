import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';

interface ProductsProps {
  category?: string;
}

const CATEGORIES = [
  { id: 'all', label: 'All Products', path: '/products' },
  { id: 'millet', label: 'Millets', path: '/products/millet' },
  { id: 'nuts', label: 'Nuts', path: '/products/nuts' },
  { id: 'rice', label: 'Rice', path: '/products/rice' },
  { id: 'spices', label: 'Spices', path: '/products/spices' }
];

export const Products: React.FC<ProductsProps> = ({ category: propCategory }) => {
  const { category: paramCategory } = useParams<{ category: string }>();
  const activeCategory = propCategory || paramCategory || 'all';
  const navigate = useNavigate();
  
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Determine display title
  const getTitle = (cat: string) => {
    switch(cat) {
      case 'millet': return 'Ancient Millets';
      case 'nuts': return 'Premium Nuts';
      case 'rice': return 'Organic Rice';
      case 'spices': return 'Aromatic Spices';
      default: return 'All Products';
    }
  };

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        // Simulating API latency
        await new Promise(resolve => setTimeout(resolve, 600));
        
        // Mocking response
        const mockProducts: Product[] = Array.from({ length: 12 }).map((_, i) => ({
          id: `${activeCategory}-${i}`,
          title: `${activeCategory === 'all' ? 'Organic' : activeCategory} Item ${i + 1}`,
          category: activeCategory === 'all' ? ['Millets', 'Nuts', 'Spices', 'Rice'][i % 4] : activeCategory,
          price: 150 + i * 40,
          image: `https://picsum.photos/400/400?random=${i}&category=${activeCategory}`,
          description: 'Premium quality organic produce sourced directly from farmers.',
          sizes: ['500g', '1kg', '5kg'],
          inStock: i % 6 !== 0 // 1 in 6 out of stock
        }));
        setProducts(mockProducts);
      } catch (error) {
        console.error("Failed to fetch products", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [activeCategory]);

  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Category Slider */}
        <div className="mb-12 overflow-x-auto no-scrollbar py-2">
          <div className="flex space-x-3 min-w-max">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => navigate(cat.path)}
                className={`px-6 py-3 rounded-full text-sm font-medium transition-all duration-300 border ${
                  (activeCategory === cat.id || (activeCategory === 'all' && cat.id === 'all'))
                    ? 'bg-brand-dark text-white border-brand-dark shadow-md' 
                    : 'bg-white text-neutral-600 border-neutral-200 hover:border-brand-accent hover:text-brand-dark'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mb-3 capitalize">
            {getTitle(activeCategory)}
          </h1>
          <p className="text-neutral-500 max-w-2xl">
            Browse our collection of ethically sourced, premium quality bulk ingredients.
          </p>
        </header>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
             {[1, 2, 3, 4, 5, 6].map(n => (
               <div key={n} className="h-96 bg-neutral-100 rounded-2xl animate-pulse"></div>
             ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};