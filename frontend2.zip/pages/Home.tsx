import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { IconArrowRight, IconChevronLeft, IconChevronRight } from '../components/Icons';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';

// Using the provided images for products
const FEATURED_PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Traditional Millets',
    category: 'Millets',
    price: 180,
    image: 'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95',
    description: 'Premium quality traditional millets, rich in fiber and nutrients.',
    sizes: ['1kg', '5kg'],
    inStock: true
  },
  {
    id: '2',
    title: 'Biriyani Rice Premium',
    category: 'Rice',
    price: 650,
    image: 'https://aistudiocdn.com/d/ef70b686-e91b-4f91-817e-7bf33f019054',
    description: 'Aromatic long-grain rice perfect for festive biriyanis.',
    sizes: ['5kg', '25kg'],
    inStock: true
  },
  {
    id: '3',
    title: 'White Rice',
    category: 'Rice',
    price: 450,
    image: 'https://aistudiocdn.com/d/312ac650-2c7b-402a-8c88-29ec3849567e',
    description: 'Daily use premium white rice processed with care.',
    sizes: ['5kg', '10kg'],
    inStock: true
  },
  {
    id: '4',
    title: 'Tinne Spices Pack',
    category: 'Spices',
    price: 320,
    image: 'https://aistudiocdn.com/d/3e4a2e5a-73d8-4fc5-9988-812699e34e55',
    description: 'Authentic spice blend from traditional recipes.',
    sizes: ['100g', '250g'],
    inStock: true
  }
];

const CATEGORIES = [
  { id: 'millet', label: 'Millets', path: '/products/millet', image: 'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95' },
  { id: 'nuts', label: 'Nuts', path: '/products/nuts', image: 'https://images.unsplash.com/photo-1596208643924-f7c8702c2869?auto=format&fit=crop&q=80&w=400' },
  { id: 'rice', label: 'Rice', path: '/products/rice', image: 'https://aistudiocdn.com/d/f3af9610-c020-4357-96a6-f2b74070a248' },
  { id: 'spices', label: 'Spices', path: '/products/spices', image: 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?auto=format&fit=crop&q=80&w=400' },
];

const BLOG_POSTS = [
  {
    id: 1,
    title: "The Revival of Ancient Grains",
    excerpt: "Why millets are making a comeback in modern Indian kitchens.",
    date: "Oct 12, 2023",
    image: "https://images.unsplash.com/photo-1486328228599-85db4443971f?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: 2,
    title: "Understanding Organic Certification",
    excerpt: "What it really means when you buy 'Certified Organic'.",
    date: "Oct 08, 2023",
    image: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: 3,
    title: "Spices as Medicine",
    excerpt: "Traditional Ayurvedic benefits of common kitchen spices.",
    date: "Sep 28, 2023",
    image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&q=80&w=400"
  }
];

// Using the provided images for the hero slider
const HERO_IMAGES = [
  'https://aistudiocdn.com/d/f3af9610-c020-4357-96a6-f2b74070a248', // Rice top view
  'https://aistudiocdn.com/d/ef70b686-e91b-4f91-817e-7bf33f019054', // Biriyani Rice Pack
  'https://aistudiocdn.com/d/1c062c3e-52f0-4660-848e-6c0b36879e95', // Millets Pack
];

export const Home: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % HERO_IMAGES.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + HERO_IMAGES.length) % HERO_IMAGES.length);

  return (
    <div className="w-full pt-20"> {/* Padding to account for fixed navbar */}
      {/* Hero Slider - Full View Height */}
      <section className="relative h-[calc(100vh-5rem)] min-h-[600px] w-full overflow-hidden bg-neutral-900">
        {HERO_IMAGES.map((img, index) => (
          <div 
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img 
              src={img} 
              alt={`Slide ${index + 1}`} 
              className="w-full h-full object-cover opacity-90"
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />
          </div>
        ))}

        {/* Hero Content Overlay */}
        <div className="absolute inset-0 flex flex-col justify-center items-center text-center px-6 z-20">
          <h1 className="font-script text-7xl md:text-9xl text-white mb-6 drop-shadow-lg opacity-95">
            Tinné
          </h1>
          <p className="text-xl md:text-3xl text-neutral-100 font-light tracking-[0.2em] uppercase mb-10 drop-shadow-md border-t border-b border-white/30 py-4 px-8 backdrop-blur-sm bg-white/5">
            From Grandma's Thinnai
          </p>
          <div className="flex gap-4">
             <Button variant="primary" size="lg" className="bg-brand-accent text-brand-dark hover:bg-white hover:text-brand-dark border-none min-w-[160px]">
              <Link to="/products">Shop Now</Link>
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-brand-dark min-w-[160px]">
              <Link to="/about">Our Story</Link>
            </Button>
          </div>
        </div>

        {/* Slider Controls */}
        <button 
          onClick={prevSlide}
          className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 backdrop-blur-md p-4 rounded-full text-white transition-all z-20 border border-white/20 hidden md:block"
        >
          <IconChevronLeft className="w-6 h-6" />
        </button>
        <button 
          onClick={nextSlide}
          className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/30 backdrop-blur-md p-4 rounded-full text-white transition-all z-20 border border-white/20 hidden md:block"
        >
          <IconChevronRight className="w-6 h-6" />
        </button>

        {/* Dots */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex space-x-4 z-20">
          {HERO_IMAGES.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                index === currentSlide ? 'bg-brand-accent w-12' : 'bg-white/50 w-3 hover:bg-white'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Product Showcases & Categories */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-16">
            <div className="max-w-xl">
              <h2 className="text-4xl font-display font-bold text-neutral-900 mb-3">Product Showcases</h2>
              <div className="h-1 w-20 bg-brand-accent mb-4"></div>
              <p className="text-neutral-500 text-lg">Curated collections handpicked for exceptional quality, purity, and freshness directly from the source.</p>
            </div>
            <Link to="/products" className="hidden md:flex items-center text-brand-dark font-bold hover:text-brand-accent transition-colors border-b-2 border-transparent hover:border-brand-accent pb-1">
              View All Collection <IconArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>

          {/* Row 1: Products */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12 mb-24">
            {FEATURED_PRODUCTS.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          {/* Row 2: Category Shortcuts */}
          <div className="mb-8">
            <div className="text-center mb-10">
               <span className="text-brand-accent font-bold tracking-wider uppercase text-sm">Discover by Category</span>
               <h3 className="text-2xl font-display font-bold text-neutral-900 mt-2">Essential Ingredients</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {CATEGORIES.map((cat) => (
                <Link 
                  key={cat.id} 
                  to={cat.path}
                  className="group relative h-64 rounded-2xl overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500"
                >
                  <img 
                    src={cat.image} 
                    alt={cat.label}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform transition-transform duration-500 group-hover:-translate-y-2">
                    <p className="font-display font-bold text-2xl mb-1">{cat.label}</p>
                    <div className="h-0.5 w-12 bg-brand-accent mb-3 transition-all duration-500 group-hover:w-full"></div>
                    <span className="text-xs font-medium uppercase tracking-widest flex items-center opacity-0 group-hover:opacity-100 transition-opacity delay-100">
                      Explore <IconArrowRight className="w-4 h-4 ml-2" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
          
          <div className="mt-12 text-center md:hidden">
             <Link to="/products">
              <Button variant="outline">View All Products</Button>
             </Link>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-24 bg-neutral-50 border-t border-neutral-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-12">
             <div>
               <h2 className="text-3xl font-display font-bold text-neutral-900">From the Journal</h2>
               <p className="text-neutral-500 mt-2">Stories of heritage, health, and sustainable living.</p>
             </div>
             <Link to="/blog" className="hidden md:inline-flex items-center text-brand-dark font-medium hover:text-brand-accent transition-colors">
               Read All Articles <IconArrowRight className="ml-2 w-4 h-4" />
             </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post) => (
              <article key={post.id} className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-500">
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-neutral-900">
                    {post.date}
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-display font-bold text-neutral-900 mb-3 group-hover:text-brand-accent transition-colors leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-neutral-600 text-sm line-clamp-2 mb-6 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <Link to="/blog" className="text-sm font-bold text-brand-dark flex items-center hover:underline uppercase tracking-wide">
                    Read Story <IconArrowRight className="w-3 h-3 ml-1" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};